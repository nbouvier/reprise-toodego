--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.0
-- Dumped by pg_dump version 14.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE test;
--
-- Name: test; Type: DATABASE; Schema: -; Owner: insertion
--

CREATE DATABASE test WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.utf8';


ALTER DATABASE test OWNER TO insertion;

\connect test

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: unaccent; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS unaccent WITH SCHEMA public;


--
-- Name: EXTENSION unaccent; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION unaccent IS 'text search dictionary that removes accents';


--
-- Name: employment_training_area_stamp(); Type: FUNCTION; Schema: public; Owner: insertion
--

CREATE FUNCTION public.employment_training_area_stamp() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    BEGIN
        IF NEW."beneficiaryEmploymentId" IS NULL THEN
            RETURN NULL;
        END IF;
        IF NEW."trainingAreaId" IS NULL THEN
            RETURN NULL;
        END IF;
        RETURN NEW;
    END;
$$;


ALTER FUNCTION public.employment_training_area_stamp() OWNER TO insertion;

--
-- Name: f_unaccent(text); Type: FUNCTION; Schema: public; Owner: insertion
--

CREATE FUNCTION public.f_unaccent(text) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$
SELECT regexp_replace(public.immutable_unaccent(regdictionary 'public.unaccent', LOWER($1)), '[^[:alnum:]]', '', 'g')
$_$;


ALTER FUNCTION public.f_unaccent(text) OWNER TO insertion;

--
-- Name: immutable_unaccent(regdictionary, text); Type: FUNCTION; Schema: public; Owner: insertion
--

CREATE FUNCTION public.immutable_unaccent(regdictionary, text) RETURNS text
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/unaccent', 'unaccent_dict';


ALTER FUNCTION public.immutable_unaccent(regdictionary, text) OWNER TO insertion;

--
-- Name: uuid_generate_v4(); Type: FUNCTION; Schema: public; Owner: insertion
--

CREATE FUNCTION public.uuid_generate_v4() RETURNS uuid
    LANGUAGE c STRICT PARALLEL SAFE
    AS '$libdir/uuid-ossp', 'uuid_generate_v4';


ALTER FUNCTION public.uuid_generate_v4() OWNER TO insertion;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: access_token; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.access_token (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "userId" integer NOT NULL,
    expires timestamp without time zone NOT NULL,
    revoked boolean DEFAULT false NOT NULL
);


ALTER TABLE public.access_token OWNER TO insertion;

--
-- Name: address; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.address (
    id integer NOT NULL,
    main character varying NOT NULL,
    complement character varying,
    "postalCode" character varying NOT NULL,
    city character varying NOT NULL
);


ALTER TABLE public.address OWNER TO insertion;

--
-- Name: agenda_event; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.agenda_event (
    id integer NOT NULL,
    title character varying,
    date date NOT NULL,
    "beginTime" time without time zone NOT NULL,
    "endTime" time without time zone,
    "eventType" character varying NOT NULL,
    notes character varying,
    "userId" integer NOT NULL,
    "supportTypeId" integer NOT NULL,
    convention boolean,
    "interviewId" integer,
    "courseId" integer
);


ALTER TABLE public.agenda_event OWNER TO insertion;

--
-- Name: agenda_event_id_seq; Type: SEQUENCE; Schema: public; Owner: insertion
--

CREATE SEQUENCE public.agenda_event_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.agenda_event_id_seq OWNER TO insertion;

--
-- Name: agenda_event_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: insertion
--

ALTER SEQUENCE public.agenda_event_id_seq OWNED BY public.agenda_event.id;


--
-- Name: beneficiary; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.beneficiary (
    id integer NOT NULL,
    "insertisId" character varying NOT NULL,
    "usualName" character varying NOT NULL,
    surname character varying,
    "firstName" character varying NOT NULL,
    "secondName" character varying,
    title character varying NOT NULL,
    "birthDate" date,
    nationality character varying NOT NULL,
    "birthPostalCode" character varying,
    "birthCity" character varying,
    "jobCenterNumber" character varying,
    "attachedOrganization" character varying,
    "recipientNumber" character varying,
    "landlineNumber" character varying,
    "cellPhoneNumber" character varying,
    sms boolean,
    "emailAddress" character varying,
    email boolean,
    "beginDateSupport" date NOT NULL,
    "lastUpdateDate" date,
    "endDateSupport" date,
    "typeSupportDetail" character varying,
    "iodasNumber" character varying,
    "idAbc" character varying,
    status character varying,
    "orientationBeginDate" date,
    "orientationEndDate" date,
    "maritalStatus" character varying,
    "supportTypeId" integer NOT NULL,
    "structureId" integer,
    "beneficiaryComplementId" integer,
    "beneficiaryEmploymentId" integer,
    "residentialAddressId" integer NOT NULL,
    "postalAddressId" integer NOT NULL
);


ALTER TABLE public.beneficiary OWNER TO insertion;

--
-- Name: beneficiary_complement; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.beneficiary_complement (
    id integer NOT NULL,
    "childrenCount" integer,
    "dependentsNumber" integer,
    "healthInsuranceId" integer,
    "rsaRightBeginDate" date,
    "referentId" integer,
    "beginDateReferent" date,
    "endDateReferent" date,
    "reasonOrientationEnding" character varying,
    "singleParent" boolean
);


ALTER TABLE public.beneficiary_complement OWNER TO insertion;

--
-- Name: orientation_history; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.orientation_history (
    id integer NOT NULL,
    "beginDate" date NOT NULL,
    "endDate" date,
    "reasonOrientationEnding" character varying,
    "structureId" integer NOT NULL,
    "beneficiaryId" integer NOT NULL
);


ALTER TABLE public.orientation_history OWNER TO insertion;

--
-- Name: aggregate_orientation; Type: VIEW; Schema: public; Owner: insertion
--

CREATE VIEW public.aggregate_orientation AS
 SELECT b.id AS "beneficiaryId",
    b."structureId",
    b."orientationBeginDate" AS "beginDate",
    b."orientationEndDate" AS "endDate",
    bc."reasonOrientationEnding"
   FROM (public.beneficiary b
     LEFT JOIN public.beneficiary_complement bc ON ((bc.id = b."beneficiaryComplementId")))
UNION
 SELECT oh."beneficiaryId",
    oh."structureId",
    oh."beginDate",
    oh."endDate",
    oh."reasonOrientationEnding"
   FROM public.orientation_history oh;


ALTER TABLE public.aggregate_orientation OWNER TO insertion;

--
-- Name: referent_history; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.referent_history (
    id integer NOT NULL,
    "beginDate" date NOT NULL,
    "endDate" date NOT NULL,
    "referentId" integer NOT NULL,
    "structureId" integer NOT NULL,
    "beneficiaryId" integer NOT NULL
);


ALTER TABLE public.referent_history OWNER TO insertion;

--
-- Name: aggregate_referent; Type: VIEW; Schema: public; Owner: insertion
--

CREATE VIEW public.aggregate_referent AS
 SELECT b.id AS "beneficiaryId",
    bc."beginDateReferent" AS "beginDate",
    bc."endDateReferent" AS "endDate",
    bc."referentId",
    b."structureId"
   FROM (public.beneficiary b
     LEFT JOIN public.beneficiary_complement bc ON ((bc.id = b."beneficiaryComplementId")))
UNION
 SELECT rh."beneficiaryId",
    rh."beginDate",
    rh."endDate",
    rh."referentId",
    rh."structureId"
   FROM public.referent_history rh;


ALTER TABLE public.aggregate_referent OWNER TO insertion;

--
-- Name: beneficiary_address; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.beneficiary_address (
    id integer NOT NULL,
    address character varying NOT NULL,
    "beginDate" date NOT NULL,
    "endDate" date,
    "additionalAddress" character varying,
    "postalCode" character varying NOT NULL,
    city character varying NOT NULL,
    "cliId" integer,
    "ctmId" integer,
    "qpvId" integer,
    "residentialStatus" character varying,
    "residentialStatusComplement" character varying,
    "domiciliationType" character varying,
    "domiciliationTypeComplement" character varying
);


ALTER TABLE public.beneficiary_address OWNER TO insertion;

--
-- Name: beneficiary_residential_history; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.beneficiary_residential_history (
    "beneficiaryId" integer NOT NULL,
    "beneficiaryAddressId" integer NOT NULL
);


ALTER TABLE public.beneficiary_residential_history OWNER TO insertion;

--
-- Name: aggregate_residential_address; Type: VIEW; Schema: public; Owner: insertion
--

CREATE VIEW public.aggregate_residential_address AS
 SELECT b.id AS "beneficiaryId",
    ba."beginDate",
    ba."endDate",
    ba.address,
    ba."additionalAddress",
    ba."postalCode",
    ba.city,
    ba."cliId",
    ba."ctmId",
    ba."qpvId",
    ba."residentialStatus",
    ba."residentialStatusComplement"
   FROM (public.beneficiary b
     LEFT JOIN public.beneficiary_address ba ON ((ba.id = b."residentialAddressId")))
UNION
 SELECT b."beneficiaryId",
    ba."beginDate",
    ba."endDate",
    ba.address,
    ba."additionalAddress",
    ba."postalCode",
    ba.city,
    ba."cliId",
    ba."ctmId",
    ba."qpvId",
    ba."residentialStatus",
    ba."residentialStatusComplement"
   FROM (public.beneficiary_residential_history b
     LEFT JOIN public.beneficiary_address ba ON ((ba.id = b."beneficiaryAddressId")));


ALTER TABLE public.aggregate_residential_address OWNER TO insertion;

--
-- Name: support_history; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.support_history (
    id integer NOT NULL,
    "beginDate" date NOT NULL,
    "endDate" date,
    "typeSupportDetail" character varying,
    "supportTypeId" integer NOT NULL,
    "beneficiaryId" integer NOT NULL
);


ALTER TABLE public.support_history OWNER TO insertion;

--
-- Name: aggregate_support_type; Type: VIEW; Schema: public; Owner: insertion
--

CREATE VIEW public.aggregate_support_type AS
 SELECT b.id AS "beneficiaryId",
    b."supportTypeId",
    b."beginDateSupport" AS "beginDate",
    b."endDateSupport" AS "endDate",
    b."typeSupportDetail"
   FROM public.beneficiary b
UNION
 SELECT sh."beneficiaryId",
    sh."supportTypeId",
    sh."beginDate",
    sh."endDate",
    sh."typeSupportDetail"
   FROM public.support_history sh;


ALTER TABLE public.aggregate_support_type OWNER TO insertion;

--
-- Name: asset; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.asset (
    id integer NOT NULL,
    label character varying NOT NULL
);


ALTER TABLE public.asset OWNER TO insertion;

--
-- Name: barrier; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.barrier (
    id integer NOT NULL,
    label character varying NOT NULL
);


ALTER TABLE public.barrier OWNER TO insertion;

--
-- Name: beneficiary_address_id_seq; Type: SEQUENCE; Schema: public; Owner: insertion
--

CREATE SEQUENCE public.beneficiary_address_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.beneficiary_address_id_seq OWNER TO insertion;

--
-- Name: beneficiary_address_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: insertion
--

ALTER SEQUENCE public.beneficiary_address_id_seq OWNED BY public.beneficiary_address.id;


--
-- Name: beneficiary_complement_id_seq; Type: SEQUENCE; Schema: public; Owner: insertion
--

CREATE SEQUENCE public.beneficiary_complement_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.beneficiary_complement_id_seq OWNER TO insertion;

--
-- Name: beneficiary_complement_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: insertion
--

ALTER SEQUENCE public.beneficiary_complement_id_seq OWNED BY public.beneficiary_complement.id;


--
-- Name: beneficiary_employment; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.beneficiary_employment (
    id integer NOT NULL,
    "accreditationSIAE" boolean NOT NULL,
    "accreditationSIAEDate" date,
    rqth boolean NOT NULL,
    "expiryRqthDate" date,
    entrepreneur character varying NOT NULL,
    "beginDateEntrepreneurship" date,
    "endDateEntrepreneurship" date,
    "sectorId" integer,
    "degreeId" integer NOT NULL,
    "studyAbroad" boolean NOT NULL,
    "wantedJobTypeId" integer
);


ALTER TABLE public.beneficiary_employment OWNER TO insertion;

--
-- Name: beneficiary_employment_id_seq; Type: SEQUENCE; Schema: public; Owner: insertion
--

CREATE SEQUENCE public.beneficiary_employment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.beneficiary_employment_id_seq OWNER TO insertion;

--
-- Name: beneficiary_employment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: insertion
--

ALTER SEQUENCE public.beneficiary_employment_id_seq OWNED BY public.beneficiary_employment.id;


--
-- Name: beneficiary_employment_jobs_job; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.beneficiary_employment_jobs_job (
    "beneficiaryEmploymentId" integer NOT NULL,
    "jobId" integer NOT NULL
);


ALTER TABLE public.beneficiary_employment_jobs_job OWNER TO insertion;

--
-- Name: beneficiary_id_seq; Type: SEQUENCE; Schema: public; Owner: insertion
--

CREATE SEQUENCE public.beneficiary_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.beneficiary_id_seq OWNER TO insertion;

--
-- Name: beneficiary_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: insertion
--

ALTER SEQUENCE public.beneficiary_id_seq OWNED BY public.beneficiary.id;


--
-- Name: beneficiary_orientation_address; Type: VIEW; Schema: public; Owner: insertion
--

CREATE VIEW public.beneficiary_orientation_address AS
 SELECT ao."beneficiaryId",
    ao."beginDate" AS "orientationBeginDate",
    ao."endDate" AS "orientationEndDate",
    aa."beginDate" AS "addressBeginDate",
    aa."endDate" AS "addressEndDate",
    aa.address,
    aa."additionalAddress",
    aa."postalCode",
    aa.city,
    ao."structureId",
    aa."cliId",
    aa."ctmId",
    aa."qpvId",
    ao."reasonOrientationEnding"
   FROM (public.aggregate_orientation ao
     LEFT JOIN public.aggregate_residential_address aa ON (((ao."beneficiaryId" = aa."beneficiaryId") AND (((ao."beginDate" >= aa."beginDate") AND (ao."beginDate" <= aa."endDate")) OR ((ao."endDate" >= aa."beginDate") AND (ao."endDate" <= aa."endDate")) OR ((aa."beginDate" <= ao."beginDate") AND ((aa."endDate" >= ao."endDate") OR (aa."endDate" IS NULL))) OR (((aa."beginDate" >= ao."beginDate") AND (aa."beginDate" <= ao."endDate")) OR ((aa."endDate" >= ao."beginDate") AND (aa."endDate" <= ao."endDate")) OR ((ao."beginDate" <= aa."beginDate") AND ((ao."endDate" >= aa."endDate") OR (ao."endDate" IS NULL)))) OR ((aa."endDate" IS NULL) AND (ao."endDate" IS NULL))))));


ALTER TABLE public.beneficiary_orientation_address OWNER TO insertion;

--
-- Name: beneficiary_orientation_referent; Type: VIEW; Schema: public; Owner: insertion
--

CREATE VIEW public.beneficiary_orientation_referent AS
 SELECT ao."beneficiaryId",
    ao."beginDate" AS "orientationBeginDate",
    ao."endDate" AS "orientationEndDate",
    ar."beginDate" AS "referentBeginDate",
    ar."endDate" AS "referentEndDate",
    ar."structureId",
    ar."referentId",
    ao."reasonOrientationEnding"
   FROM (public.aggregate_orientation ao
     LEFT JOIN public.aggregate_referent ar ON (((ao."beneficiaryId" = ar."beneficiaryId") AND (((ao."beginDate" >= ar."beginDate") AND (ao."beginDate" <= ar."endDate")) OR ((ao."endDate" >= ar."beginDate") AND (ao."endDate" <= ar."endDate")) OR ((ar."beginDate" <= ao."beginDate") AND ((ar."endDate" >= ao."endDate") OR (ar."endDate" IS NULL))) OR (((ar."beginDate" >= ao."beginDate") AND (ar."beginDate" <= ao."endDate")) OR ((ar."endDate" >= ao."beginDate") AND (ar."endDate" <= ao."endDate")) OR ((ao."beginDate" <= ar."beginDate") AND ((ao."endDate" >= ar."endDate") OR (ao."endDate" IS NULL)))) OR ((ar."endDate" IS NULL) AND (ao."endDate" IS NULL))))));


ALTER TABLE public.beneficiary_orientation_referent OWNER TO insertion;

--
-- Name: beneficiary_orientation_support_type; Type: VIEW; Schema: public; Owner: insertion
--

CREATE VIEW public.beneficiary_orientation_support_type AS
 SELECT ao."beneficiaryId",
    ao."beginDate" AS "orientationBeginDate",
    ao."endDate" AS "orientationEndDate",
    ast."beginDate" AS "supportBeginDate",
    ast."endDate" AS "supportEndDate",
    ao."structureId",
    ast."supportTypeId",
    ast."typeSupportDetail" AS "supportTypeDetail",
    ao."reasonOrientationEnding"
   FROM (public.aggregate_orientation ao
     LEFT JOIN public.aggregate_support_type ast ON (((ao."beneficiaryId" = ast."beneficiaryId") AND (((ao."beginDate" >= ast."beginDate") AND (ao."beginDate" <= ast."endDate")) OR ((ao."endDate" >= ast."beginDate") AND (ao."endDate" <= ast."endDate")) OR ((ast."beginDate" <= ao."beginDate") AND ((ast."endDate" >= ao."endDate") OR (ast."endDate" IS NULL))) OR (((ast."beginDate" >= ao."beginDate") AND (ast."beginDate" <= ao."endDate")) OR ((ast."endDate" >= ao."beginDate") AND (ast."endDate" <= ao."endDate")) OR ((ao."beginDate" <= ast."beginDate") AND ((ao."endDate" >= ast."endDate") OR (ao."endDate" IS NULL)))) OR ((ast."endDate" IS NULL) AND (ao."endDate" IS NULL))))));


ALTER TABLE public.beneficiary_orientation_support_type OWNER TO insertion;

--
-- Name: beneficiary_postal_history; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.beneficiary_postal_history (
    "beneficiaryId" integer NOT NULL,
    "beneficiaryAddressId" integer NOT NULL
);


ALTER TABLE public.beneficiary_postal_history OWNER TO insertion;

--
-- Name: beneficiary_rsj_id_seq; Type: SEQUENCE; Schema: public; Owner: insertion
--

CREATE SEQUENCE public.beneficiary_rsj_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.beneficiary_rsj_id_seq OWNER TO insertion;

--
-- Name: beneficiary_rsj; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.beneficiary_rsj (
    id integer DEFAULT nextval('public.beneficiary_rsj_id_seq'::regclass) NOT NULL,
    "rsjBeginDate" date,
    "rsjEndDate" date,
    "stateId" integer NOT NULL,
    "reasonId" integer,
    "beneficiaryId" integer NOT NULL,
    "referentId" integer,
    "paymentDataId" integer,
    "remainingPayment" integer DEFAULT 24
);


ALTER TABLE public.beneficiary_rsj OWNER TO insertion;

--
-- Name: beneficiary_rsj_payment_data_history; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.beneficiary_rsj_payment_data_history (
    "beneficiaryRsjId" integer NOT NULL,
    "rsjPaymentDataId" integer NOT NULL
);


ALTER TABLE public.beneficiary_rsj_payment_data_history OWNER TO insertion;

--
-- Name: beneficiary_rsj_referent_history; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.beneficiary_rsj_referent_history (
    "beneficiaryRsjId" integer NOT NULL,
    "referentId" integer NOT NULL
);


ALTER TABLE public.beneficiary_rsj_referent_history OWNER TO insertion;

--
-- Name: children; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.children (
    id integer NOT NULL,
    "childAge" character varying NOT NULL,
    "childOccupation" character varying,
    "diagnosticId" integer NOT NULL
);


ALTER TABLE public.children OWNER TO insertion;

--
-- Name: children_id_seq; Type: SEQUENCE; Schema: public; Owner: insertion
--

CREATE SEQUENCE public.children_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.children_id_seq OWNER TO insertion;

--
-- Name: children_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: insertion
--

ALTER SEQUENCE public.children_id_seq OWNED BY public.children.id;


--
-- Name: clearance; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.clearance (
    name character varying NOT NULL,
    label character varying NOT NULL,
    "categoryName" character varying NOT NULL
);


ALTER TABLE public.clearance OWNER TO insertion;

--
-- Name: clearance_category; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.clearance_category (
    name character varying NOT NULL,
    label character varying NOT NULL
);


ALTER TABLE public.clearance_category OWNER TO insertion;

--
-- Name: clearance_group; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.clearance_group (
    "clearanceName" character varying NOT NULL,
    "groupName" character varying NOT NULL
);


ALTER TABLE public.clearance_group OWNER TO insertion;

--
-- Name: clearance_user; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.clearance_user (
    "clearanceName" character varying NOT NULL,
    "userId" integer NOT NULL
);


ALTER TABLE public.clearance_user OWNER TO insertion;

--
-- Name: cli; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.cli (
    id integer NOT NULL,
    label character varying NOT NULL
);


ALTER TABLE public.cli OWNER TO insertion;

--
-- Name: community_action; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.community_action (
    id integer NOT NULL,
    "structureId" integer,
    "stageNatureTypeId" integer NOT NULL,
    "coOrganizer" character varying,
    description character varying,
    duration integer NOT NULL,
    label character varying NOT NULL,
    location character varying,
    "seatsNumber" integer NOT NULL,
    "isDirection" boolean DEFAULT false NOT NULL,
    "cliId" integer,
    "ctmId" integer,
    "creationDate" timestamp without time zone DEFAULT now() NOT NULL,
    "organizationLabel" character varying NOT NULL,
    "isActif" boolean DEFAULT true NOT NULL,
    "withSession" boolean DEFAULT true NOT NULL,
    "targetedPublic" character varying,
    requirement character varying,
    geotag character varying,
    "openAction" boolean DEFAULT false NOT NULL
);


ALTER TABLE public.community_action OWNER TO insertion;

--
-- Name: community_action_id_seq; Type: SEQUENCE; Schema: public; Owner: insertion
--

CREATE SEQUENCE public.community_action_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.community_action_id_seq OWNER TO insertion;

--
-- Name: community_action_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: insertion
--

ALTER SEQUENCE public.community_action_id_seq OWNED BY public.community_action.id;


--
-- Name: contract; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.contract (
    id integer NOT NULL,
    "beginDate" date NOT NULL,
    "endDate" date NOT NULL,
    "contractType" character varying NOT NULL,
    "mainPurpose" character varying NOT NULL,
    project character varying,
    "actionsToPerform" character varying,
    status character varying NOT NULL,
    achievement character varying,
    "statusDate" date NOT NULL,
    "beneficiaryId" integer NOT NULL,
    "structureSignatoryId" integer,
    "directionSignatoryId" integer,
    "structureId" integer,
    "referentId" integer,
    "supportTypeId" integer
);


ALTER TABLE public.contract OWNER TO insertion;

--
-- Name: contract_id_seq; Type: SEQUENCE; Schema: public; Owner: insertion
--

CREATE SEQUENCE public.contract_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.contract_id_seq OWNER TO insertion;

--
-- Name: contract_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: insertion
--

ALTER SEQUENCE public.contract_id_seq OWNED BY public.contract.id;


--
-- Name: contract_ier; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.contract_ier (
    id integer NOT NULL,
    "beginDate" date NOT NULL,
    "endDate" date NOT NULL,
    "contractType" character varying NOT NULL,
    "mainPurpose" character varying NOT NULL,
    project character varying,
    "actionsToPerform" character varying,
    status character varying NOT NULL,
    achievement character varying,
    "statusDate" date NOT NULL,
    "beneficiaryId" integer NOT NULL,
    "structureSignatoryId" integer,
    "directionSignatoryId" integer,
    "structureId" integer,
    "referentId" integer,
    "supportTypeId" integer
);


ALTER TABLE public.contract_ier OWNER TO insertion;

--
-- Name: contract_ier_id_seq; Type: SEQUENCE; Schema: public; Owner: insertion
--

CREATE SEQUENCE public.contract_ier_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.contract_ier_id_seq OWNER TO insertion;

--
-- Name: contract_ier_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: insertion
--

ALTER SEQUENCE public.contract_ier_id_seq OWNED BY public.contract_ier.id;


--
-- Name: course; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.course (
    id integer NOT NULL,
    day date NOT NULL,
    "beginTime" time without time zone NOT NULL,
    "endTime" time without time zone NOT NULL,
    "sessionId" integer NOT NULL,
    "eventId" integer NOT NULL
);


ALTER TABLE public.course OWNER TO insertion;

--
-- Name: course_id_seq; Type: SEQUENCE; Schema: public; Owner: insertion
--

CREATE SEQUENCE public.course_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.course_id_seq OWNER TO insertion;

--
-- Name: course_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: insertion
--

ALTER SEQUENCE public.course_id_seq OWNED BY public.course.id;


--
-- Name: ctm; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.ctm (
    id integer NOT NULL,
    label character varying NOT NULL
);


ALTER TABLE public.ctm OWNER TO insertion;

--
-- Name: custom_query; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.custom_query (
    id integer NOT NULL,
    name character varying NOT NULL,
    query jsonb NOT NULL,
    "userId" integer NOT NULL,
    shared boolean DEFAULT false NOT NULL
);


ALTER TABLE public.custom_query OWNER TO insertion;

--
-- Name: custom_query_id_seq; Type: SEQUENCE; Schema: public; Owner: insertion
--

CREATE SEQUENCE public.custom_query_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.custom_query_id_seq OWNER TO insertion;

--
-- Name: custom_query_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: insertion
--

ALTER SEQUENCE public.custom_query_id_seq OWNED BY public.custom_query.id;


--
-- Name: dashboard_counter; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.dashboard_counter (
    id integer NOT NULL,
    date date NOT NULL,
    "time" time without time zone NOT NULL,
    "user" character varying NOT NULL,
    profil character varying NOT NULL,
    type character varying NOT NULL
);


ALTER TABLE public.dashboard_counter OWNER TO insertion;

--
-- Name: dashboard_counter_id_seq; Type: SEQUENCE; Schema: public; Owner: insertion
--

CREATE SEQUENCE public.dashboard_counter_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dashboard_counter_id_seq OWNER TO insertion;

--
-- Name: dashboard_counter_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: insertion
--

ALTER SEQUENCE public.dashboard_counter_id_seq OWNED BY public.dashboard_counter.id;


--
-- Name: degree; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.degree (
    id integer NOT NULL,
    label character varying NOT NULL
);


ALTER TABLE public.degree OWNER TO insertion;

--
-- Name: diagnostic; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.diagnostic (
    id integer NOT NULL,
    "beginDateOrientation" date NOT NULL,
    "diagnosticStatus" character varying NOT NULL,
    "statusDate" date NOT NULL,
    title character varying NOT NULL,
    "usualName" character varying NOT NULL,
    "firstName" character varying NOT NULL,
    "birthDate" date NOT NULL,
    address character varying NOT NULL,
    "additionalAddress" character varying,
    "postalCode" character varying NOT NULL,
    city character varying NOT NULL,
    "residentialStatus" character varying,
    "residentialStatusComplement" character varying,
    "maritalStatus" character varying,
    "spouseAge" character varying,
    "spouseOccupation" character varying,
    "jobCenterRegistration" boolean NOT NULL,
    "RSA" boolean NOT NULL,
    "RQTH" boolean NOT NULL,
    mission boolean,
    "natureLastJob" character varying,
    "beginDateLastJob" date,
    "endDateLastJob" date,
    "degreeId" integer,
    "highestDegree" character varying,
    "drivingLicense" boolean NOT NULL,
    skills character varying,
    "structureId" integer,
    "referentId" integer NOT NULL,
    project character varying,
    analysis1 character varying,
    analysis2 character varying,
    analysis3 character varying,
    analysis4 character varying,
    analysis5 character varying,
    analysis6 character varying,
    "beneficiaryId" integer NOT NULL
);


ALTER TABLE public.diagnostic OWNER TO insertion;

--
-- Name: diagnostic_barrier; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.diagnostic_barrier (
    id integer NOT NULL,
    "barrierStatus" character varying NOT NULL,
    description character varying,
    "barrierId" integer NOT NULL,
    "diagnosticId" integer NOT NULL
);


ALTER TABLE public.diagnostic_barrier OWNER TO insertion;

--
-- Name: diagnostic_barrier_id_seq; Type: SEQUENCE; Schema: public; Owner: insertion
--

CREATE SEQUENCE public.diagnostic_barrier_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.diagnostic_barrier_id_seq OWNER TO insertion;

--
-- Name: diagnostic_barrier_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: insertion
--

ALTER SEQUENCE public.diagnostic_barrier_id_seq OWNED BY public.diagnostic_barrier.id;


--
-- Name: diagnostic_id_seq; Type: SEQUENCE; Schema: public; Owner: insertion
--

CREATE SEQUENCE public.diagnostic_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.diagnostic_id_seq OWNER TO insertion;

--
-- Name: diagnostic_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: insertion
--

ALTER SEQUENCE public.diagnostic_id_seq OWNED BY public.diagnostic.id;


--
-- Name: diagnostic_qualification_type; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.diagnostic_qualification_type (
    id integer NOT NULL,
    "qualificationDate" date NOT NULL,
    "qualificationDesc" character varying,
    "diagnosticId" integer NOT NULL
);


ALTER TABLE public.diagnostic_qualification_type OWNER TO insertion;

--
-- Name: diagnostic_qualification_type_id_seq; Type: SEQUENCE; Schema: public; Owner: insertion
--

CREATE SEQUENCE public.diagnostic_qualification_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.diagnostic_qualification_type_id_seq OWNER TO insertion;

--
-- Name: diagnostic_qualification_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: insertion
--

ALTER SEQUENCE public.diagnostic_qualification_type_id_seq OWNED BY public.diagnostic_qualification_type.id;


--
-- Name: document; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.document (
    id integer NOT NULL,
    "titleId" integer NOT NULL,
    "importDate" date NOT NULL,
    "importedById" integer NOT NULL,
    filename character varying NOT NULL,
    filedata character varying,
    "beneficiaryId" integer NOT NULL
);


ALTER TABLE public.document OWNER TO insertion;

--
-- Name: document_id_seq; Type: SEQUENCE; Schema: public; Owner: insertion
--

CREATE SEQUENCE public.document_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.document_id_seq OWNER TO insertion;

--
-- Name: document_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: insertion
--

ALTER SEQUENCE public.document_id_seq OWNED BY public.document.id;


--
-- Name: document_title; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.document_title (
    id integer NOT NULL,
    label character varying NOT NULL,
    tag character varying NOT NULL
);


ALTER TABLE public.document_title OWNER TO insertion;

--
-- Name: document_parcours; Type: VIEW; Schema: public; Owner: insertion
--

CREATE VIEW public.document_parcours AS
 SELECT d.id,
    d."titleId",
    d."importDate",
    d."importedById",
    d.filename,
    d."beneficiaryId"
   FROM (public.document d
     LEFT JOIN public.document_title dt ON ((dt.id = d."titleId")))
  WHERE ((dt.tag)::text = 'parcours'::text);


ALTER TABLE public.document_parcours OWNER TO insertion;

--
-- Name: document_status; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.document_status (
    id character varying NOT NULL,
    "documentId" integer NOT NULL,
    "deliveryStatus" character varying,
    "deliveryResult" character varying,
    attempts integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.document_status OWNER TO insertion;

--
-- Name: domain; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.domain (
    id integer NOT NULL,
    label character varying NOT NULL,
    "codeRome" character varying,
    "sectorId" integer NOT NULL
);


ALTER TABLE public.domain OWNER TO insertion;

--
-- Name: domain_id_seq; Type: SEQUENCE; Schema: public; Owner: insertion
--

CREATE SEQUENCE public.domain_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.domain_id_seq OWNER TO insertion;

--
-- Name: domain_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: insertion
--

ALTER SEQUENCE public.domain_id_seq OWNED BY public.domain.id;


--
-- Name: employment_asset; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.employment_asset (
    id integer NOT NULL,
    "assetId" integer NOT NULL,
    description character varying,
    "beneficiaryEmploymentId" integer NOT NULL
);


ALTER TABLE public.employment_asset OWNER TO insertion;

--
-- Name: employment_asset_id_seq; Type: SEQUENCE; Schema: public; Owner: insertion
--

CREATE SEQUENCE public.employment_asset_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.employment_asset_id_seq OWNER TO insertion;

--
-- Name: employment_asset_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: insertion
--

ALTER SEQUENCE public.employment_asset_id_seq OWNED BY public.employment_asset.id;


--
-- Name: employment_barrier; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.employment_barrier (
    id integer NOT NULL,
    description character varying,
    "barrierStatus" character varying NOT NULL,
    "barrierId" integer NOT NULL,
    "beneficiaryEmploymentId" integer NOT NULL
);


ALTER TABLE public.employment_barrier OWNER TO insertion;

--
-- Name: employment_barrier_id_seq; Type: SEQUENCE; Schema: public; Owner: insertion
--

CREATE SEQUENCE public.employment_barrier_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.employment_barrier_id_seq OWNER TO insertion;

--
-- Name: employment_barrier_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: insertion
--

ALTER SEQUENCE public.employment_barrier_id_seq OWNED BY public.employment_barrier.id;


--
-- Name: employment_qualification_type; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.employment_qualification_type (
    id integer NOT NULL,
    "qualificationDate" date NOT NULL,
    "qualificationTypeId" integer NOT NULL,
    "qualificationDesc" character varying,
    "beneficiaryEmploymentId" integer NOT NULL
);


ALTER TABLE public.employment_qualification_type OWNER TO insertion;

--
-- Name: employment_qualification_type_id_seq; Type: SEQUENCE; Schema: public; Owner: insertion
--

CREATE SEQUENCE public.employment_qualification_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.employment_qualification_type_id_seq OWNER TO insertion;

--
-- Name: employment_qualification_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: insertion
--

ALTER SEQUENCE public.employment_qualification_type_id_seq OWNED BY public.employment_qualification_type.id;


--
-- Name: employment_training_area; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.employment_training_area (
    "beneficiaryEmploymentId" integer NOT NULL,
    "trainingAreaId" integer NOT NULL
);


ALTER TABLE public.employment_training_area OWNER TO insertion;

--
-- Name: employment_transport_mode; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.employment_transport_mode (
    id integer NOT NULL,
    description character varying,
    "transportModeId" integer NOT NULL,
    "beneficiaryEmploymentId" integer NOT NULL
);


ALTER TABLE public.employment_transport_mode OWNER TO insertion;

--
-- Name: employment_transport_mode_id_seq; Type: SEQUENCE; Schema: public; Owner: insertion
--

CREATE SEQUENCE public.employment_transport_mode_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.employment_transport_mode_id_seq OWNER TO insertion;

--
-- Name: employment_transport_mode_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: insertion
--

ALTER SEQUENCE public.employment_transport_mode_id_seq OWNED BY public.employment_transport_mode.id;


--
-- Name: enrol; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.enrol (
    id integer NOT NULL,
    "sessionId" integer NOT NULL,
    "beneficiaryId" integer NOT NULL,
    "stageId" integer,
    comment character varying,
    referee character varying NOT NULL,
    status character varying NOT NULL,
    name character varying NOT NULL,
    firstname character varying NOT NULL,
    "structureLabel" character varying NOT NULL,
    "supportType" character varying NOT NULL
);


ALTER TABLE public.enrol OWNER TO insertion;

--
-- Name: enrol_id_seq; Type: SEQUENCE; Schema: public; Owner: insertion
--

CREATE SEQUENCE public.enrol_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.enrol_id_seq OWNER TO insertion;

--
-- Name: enrol_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: insertion
--

ALTER SEQUENCE public.enrol_id_seq OWNED BY public.enrol.id;


--
-- Name: focus_area; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.focus_area (
    id integer NOT NULL,
    label character varying NOT NULL
);


ALTER TABLE public.focus_area OWNER TO insertion;

--
-- Name: formation; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.formation (
    id integer NOT NULL,
    "trainingTitle" character varying NOT NULL,
    "beginDateFormation" date,
    "endDateFormation" date,
    "diagnosticId" integer NOT NULL
);


ALTER TABLE public.formation OWNER TO insertion;

--
-- Name: formation_id_seq; Type: SEQUENCE; Schema: public; Owner: insertion
--

CREATE SEQUENCE public.formation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.formation_id_seq OWNER TO insertion;

--
-- Name: formation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: insertion
--

ALTER SEQUENCE public.formation_id_seq OWNED BY public.formation.id;


--
-- Name: group; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public."group" (
    name character varying NOT NULL,
    label character varying NOT NULL
);


ALTER TABLE public."group" OWNER TO insertion;

--
-- Name: health_insurance; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.health_insurance (
    id integer NOT NULL,
    label character varying NOT NULL
);


ALTER TABLE public.health_insurance OWNER TO insertion;

--
-- Name: home; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.home (
    id integer NOT NULL,
    message character varying NOT NULL
);


ALTER TABLE public.home OWNER TO insertion;

--
-- Name: home_id_seq; Type: SEQUENCE; Schema: public; Owner: insertion
--

CREATE SEQUENCE public.home_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.home_id_seq OWNER TO insertion;

--
-- Name: home_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: insertion
--

ALTER SEQUENCE public.home_id_seq OWNED BY public.home.id;


--
-- Name: instruction_rsj; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.instruction_rsj (
    id integer NOT NULL,
    "instructionDate" date NOT NULL,
    "directedByName" character varying NOT NULL,
    "directedById" integer,
    "referentName" character varying NOT NULL,
    "structureLabel" character varying NOT NULL,
    title character varying NOT NULL,
    surname character varying NOT NULL,
    "usualName" character varying NOT NULL,
    "firstName" character varying NOT NULL,
    "birthDate" date NOT NULL,
    nationality character varying NOT NULL,
    "credentialType" character varying,
    "credentialDocument1Id" integer,
    "credentialDocumentDate1" date,
    "credentialDocument2Id" integer,
    "credentialDocumentDate2" date,
    "credentialDocument3Id" integer,
    "credentialDocumentDate3" date,
    "residentialAddressId" integer NOT NULL,
    "postalAddressId" integer NOT NULL,
    "addressDocument1Id" integer,
    "addressDocument2Id" integer,
    "sixMonthsResident" boolean,
    "outOfEducationSystem" boolean,
    "taxSituation" character varying,
    "familyQuotient" integer,
    "otherIncomePrecision" character varying,
    "withoutSolidarityPlan" boolean,
    "withoutYouthPlan" boolean,
    "socialCareInProgress" boolean,
    "socialStructureName" character varying,
    "aseService" boolean,
    "aseServiceLyon" boolean,
    "rsaSimulation" boolean,
    "maritalStatus" character varying,
    "dependentsNumber" integer,
    "complementaryHealth" boolean,
    "givenUpCareInPast6Months" boolean,
    "individualInternetAccess" boolean,
    "connectedToTCLNetwork" boolean,
    "leisureAccessInPast12Months" boolean,
    "hostedFreeOfCharge" boolean,
    "decohabitationStatus" character varying,
    "shelterRegistration" boolean,
    "residentialSituationDuration" character varying,
    "searchingForHousing" boolean,
    "housingProcessStarted" boolean,
    "housingProcessWithHelp" boolean,
    "housingProcessWithHelpBy" character varying,
    "structureAddress" character varying NOT NULL,
    "structureAdditionalAddress" character varying,
    "structurePostalCode" character varying NOT NULL,
    "structureCity" character varying NOT NULL,
    "structurePhone" character varying,
    "referentPhone" character varying,
    "commitmentForNext3Months" character varying,
    assessment character varying,
    "situationComment" character varying,
    "beneficiaryId" integer,
    "structureId" integer,
    "healthInsuranceId" integer,
    "nonRenewalId" integer,
    "nonRenewalComment" character varying,
    "underSupervision" boolean,
    "supervisionDocument1Id" integer,
    "supervisionDocument2Id" integer,
    "partnerOnRsa" boolean,
    pregnancy boolean,
    "rsaSimulationComment" character varying,
    "parentsOnRsa" boolean,
    "taxDetachment" character varying,
    "breakupComment" character varying,
    entrepreneur character varying,
    "paymentAmount" integer,
    "paymentOpinion" character varying,
    "paymentComment" character varying,
    "paymentCounterProposal" boolean,
    "paymentCounterAmount" integer,
    "paymentCounterComment" character varying,
    "useTitleId" integer,
    "useTitleComment" character varying,
    status character varying NOT NULL,
    "statusDate" date NOT NULL,
    "paymentDuration" integer,
    "paymentCounterDuration" integer
);


ALTER TABLE public.instruction_rsj OWNER TO insertion;

--
-- Name: instruction_rsj_id_seq; Type: SEQUENCE; Schema: public; Owner: insertion
--

CREATE SEQUENCE public.instruction_rsj_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.instruction_rsj_id_seq OWNER TO insertion;

--
-- Name: instruction_rsj_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: insertion
--

ALTER SEQUENCE public.instruction_rsj_id_seq OWNED BY public.instruction_rsj.id;


--
-- Name: instruction_rsj_income; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.instruction_rsj_income (
    id integer NOT NULL,
    type character varying NOT NULL,
    "previousMonth" integer NOT NULL,
    "currentMonth" integer NOT NULL,
    "nextMonth" integer NOT NULL,
    "nextTwoMonth" integer NOT NULL,
    "nextThreeMonth" integer NOT NULL,
    "instructionRSJId" integer
);


ALTER TABLE public.instruction_rsj_income OWNER TO insertion;

--
-- Name: instruction_rsj_income_id_seq; Type: SEQUENCE; Schema: public; Owner: insertion
--

CREATE SEQUENCE public.instruction_rsj_income_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.instruction_rsj_income_id_seq OWNER TO insertion;

--
-- Name: instruction_rsj_income_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: insertion
--

ALTER SEQUENCE public.instruction_rsj_income_id_seq OWNED BY public.instruction_rsj_income.id;


--
-- Name: instruction_rsj_mobilized_plan; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.instruction_rsj_mobilized_plan (
    "instructionRsjId" integer NOT NULL,
    "rsjMobilizedPlanId" integer NOT NULL
);


ALTER TABLE public.instruction_rsj_mobilized_plan OWNER TO insertion;

--
-- Name: instruction_rsj_non_renewal; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.instruction_rsj_non_renewal (
    id integer NOT NULL,
    reason character varying NOT NULL,
    detail character varying NOT NULL
);


ALTER TABLE public.instruction_rsj_non_renewal OWNER TO insertion;

--
-- Name: instruction_rsj_other_document; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.instruction_rsj_other_document (
    "instructionRsjId" integer NOT NULL,
    "documentId" integer NOT NULL,
    comment character varying
);


ALTER TABLE public.instruction_rsj_other_document OWNER TO insertion;

--
-- Name: instruction_rsj_situation; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.instruction_rsj_situation (
    "instructionRsjId" integer NOT NULL,
    "rsjSituationId" integer NOT NULL,
    comment character varying
);


ALTER TABLE public.instruction_rsj_situation OWNER TO insertion;

--
-- Name: instruction_rsj_use_title; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.instruction_rsj_use_title (
    id integer NOT NULL,
    label character varying NOT NULL
);


ALTER TABLE public.instruction_rsj_use_title OWNER TO insertion;

--
-- Name: interview; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.interview (
    id integer NOT NULL,
    "interviewDate" date NOT NULL,
    "beginTimeInterview" time without time zone NOT NULL,
    "endTimeInterview" time without time zone,
    "directedById" integer,
    "interviewType" character varying,
    presence character varying,
    synthesis character varying,
    note character varying,
    "beneficiaryId" integer NOT NULL,
    "structureId" integer NOT NULL,
    "interviewThemeId" integer,
    "addressId" integer NOT NULL
);


ALTER TABLE public.interview OWNER TO insertion;

--
-- Name: interview_id_seq; Type: SEQUENCE; Schema: public; Owner: insertion
--

CREATE SEQUENCE public.interview_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.interview_id_seq OWNER TO insertion;

--
-- Name: interview_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: insertion
--

ALTER SEQUENCE public.interview_id_seq OWNED BY public.interview.id;


--
-- Name: interview_support_type; Type: VIEW; Schema: public; Owner: insertion
--

CREATE VIEW public.interview_support_type AS
 SELECT i.id,
    i."interviewDate",
    i."beginTimeInterview",
    i."endTimeInterview",
    (EXTRACT(epoch FROM (i."endTimeInterview" - i."beginTimeInterview")) / (60)::numeric) AS "durationInterview",
    i."directedById",
    i."interviewType",
    i.presence,
    i.synthesis,
    i.note,
    i."beneficiaryId",
    i."structureId",
    i."interviewThemeId",
    i."addressId",
    ast."supportTypeId"
   FROM (public.interview i
     LEFT JOIN public.aggregate_support_type ast ON (((i."beneficiaryId" = ast."beneficiaryId") AND (((ast."endDate" IS NOT NULL) AND ((i."interviewDate" >= ast."beginDate") AND (i."interviewDate" <= ast."endDate"))) OR ((ast."endDate" IS NULL) AND (ast."beginDate" <= i."interviewDate"))))));


ALTER TABLE public.interview_support_type OWNER TO insertion;

--
-- Name: interview_theme; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.interview_theme (
    id integer NOT NULL,
    label character varying NOT NULL
);


ALTER TABLE public.interview_theme OWNER TO insertion;

--
-- Name: interview_theme_id_seq; Type: SEQUENCE; Schema: public; Owner: insertion
--

CREATE SEQUENCE public.interview_theme_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.interview_theme_id_seq OWNER TO insertion;

--
-- Name: interview_theme_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: insertion
--

ALTER SEQUENCE public.interview_theme_id_seq OWNED BY public.interview_theme.id;


--
-- Name: job; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.job (
    id integer NOT NULL,
    label character varying NOT NULL,
    "codeRome" character varying,
    "domainId" integer
);


ALTER TABLE public.job OWNER TO insertion;

--
-- Name: job_id_seq; Type: SEQUENCE; Schema: public; Owner: insertion
--

CREATE SEQUENCE public.job_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.job_id_seq OWNER TO insertion;

--
-- Name: job_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: insertion
--

ALTER SEQUENCE public.job_id_seq OWNED BY public.job.id;


--
-- Name: job_type; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.job_type (
    id integer NOT NULL,
    label character varying NOT NULL
);


ALTER TABLE public.job_type OWNER TO insertion;

--
-- Name: survey_fse; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.survey_fse (
    id integer NOT NULL,
    "beginDate" date NOT NULL,
    "endDate" date NOT NULL,
    "directedById" integer NOT NULL,
    "beneficiaryId" integer NOT NULL,
    "structureOrganizationId" integer NOT NULL,
    "actionId" integer,
    year integer NOT NULL,
    "isAnnualMonitoring" boolean NOT NULL,
    "exitQuestion1" boolean,
    "exitQuestion2" character varying,
    "exitQuestion3" character varying,
    "exitQuestion4" character varying,
    "exitQuestion5" character varying,
    "exitQuestion6" character varying,
    "exitQuestion7" character varying,
    "exitQuestion8" character varying,
    "entryQuestion1" character varying NOT NULL,
    "entryQuestion1e" character varying,
    "entryQuestion1f" character varying,
    month integer,
    "entryQuestion2" character varying NOT NULL,
    "entryQuestion3" character varying NOT NULL,
    "entryQuestion4" character varying NOT NULL,
    "entryQuestion5" character varying NOT NULL,
    "entryQuestion6" character varying NOT NULL
);


ALTER TABLE public.survey_fse OWNER TO insertion;

--
-- Name: labeled_survey_fse; Type: VIEW; Schema: public; Owner: insertion
--

CREATE VIEW public.labeled_survey_fse AS
 SELECT survey_fse.id,
        CASE survey_fse."isAnnualMonitoring"
            WHEN true THEN 'Suivi annuel'::character varying
            WHEN false THEN community_action.label
            ELSE NULL::character varying
        END AS label,
    survey_fse."beginDate",
    survey_fse."endDate",
    survey_fse."structureOrganizationId",
    survey_fse.year,
    survey_fse."directedById",
    survey_fse."isAnnualMonitoring",
    survey_fse."beneficiaryId"
   FROM (public.survey_fse
     LEFT JOIN public.community_action ON ((community_action.id = survey_fse."actionId")));


ALTER TABLE public.labeled_survey_fse OWNER TO insertion;

--
-- Name: log; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.log (
    id integer NOT NULL,
    name character varying NOT NULL,
    "creationDate" timestamp without time zone NOT NULL
);


ALTER TABLE public.log OWNER TO insertion;

--
-- Name: log_id_seq; Type: SEQUENCE; Schema: public; Owner: insertion
--

CREATE SEQUENCE public.log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.log_id_seq OWNER TO insertion;

--
-- Name: log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: insertion
--

ALTER SEQUENCE public.log_id_seq OWNED BY public.log.id;


--
-- Name: logo; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.logo (
    id integer NOT NULL,
    name character varying NOT NULL,
    "rawData" character varying NOT NULL
);


ALTER TABLE public.logo OWNER TO insertion;

--
-- Name: logo_id_seq; Type: SEQUENCE; Schema: public; Owner: insertion
--

CREATE SEQUENCE public.logo_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.logo_id_seq OWNER TO insertion;

--
-- Name: logo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: insertion
--

ALTER SEQUENCE public.logo_id_seq OWNED BY public.logo.id;


--
-- Name: metropole_town; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.metropole_town (
    "codeInsee" character varying NOT NULL,
    denomination character varying NOT NULL,
    "postalCode" character varying NOT NULL,
    "ctmId" integer
);


ALTER TABLE public.metropole_town OWNER TO insertion;

--
-- Name: orientation_history_id_seq; Type: SEQUENCE; Schema: public; Owner: insertion
--

CREATE SEQUENCE public.orientation_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.orientation_history_id_seq OWNER TO insertion;

--
-- Name: orientation_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: insertion
--

ALTER SEQUENCE public.orientation_history_id_seq OWNED BY public.orientation_history.id;


--
-- Name: postal_address; Type: VIEW; Schema: public; Owner: insertion
--

CREATE VIEW public.postal_address AS
 SELECT b.id AS "beneficiaryId",
    ba.id,
    ba."beginDate",
    ba."endDate",
    ba.address,
    ba."additionalAddress",
    ba."postalCode",
    ba.city,
    ba."domiciliationType",
    ba."domiciliationTypeComplement"
   FROM (public.beneficiary b
     LEFT JOIN public.beneficiary_address ba ON ((ba.id = b."postalAddressId")));


ALTER TABLE public.postal_address OWNER TO insertion;

--
-- Name: postal_address_history; Type: VIEW; Schema: public; Owner: insertion
--

CREATE VIEW public.postal_address_history AS
 SELECT b."beneficiaryId",
    ba.id,
    ba."beginDate",
    ba."endDate",
    ba.address,
    ba."additionalAddress",
    ba."postalCode",
    ba.city,
    ba."domiciliationType",
    ba."domiciliationTypeComplement"
   FROM (public.beneficiary_postal_history b
     LEFT JOIN public.beneficiary_address ba ON ((ba.id = b."beneficiaryAddressId")));


ALTER TABLE public.postal_address_history OWNER TO insertion;

--
-- Name: qpv; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.qpv (
    id integer NOT NULL,
    municipality character varying NOT NULL,
    district character varying NOT NULL
);


ALTER TABLE public.qpv OWNER TO insertion;

--
-- Name: qpv_id_seq; Type: SEQUENCE; Schema: public; Owner: insertion
--

CREATE SEQUENCE public.qpv_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.qpv_id_seq OWNER TO insertion;

--
-- Name: qpv_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: insertion
--

ALTER SEQUENCE public.qpv_id_seq OWNED BY public.qpv.id;


--
-- Name: qualification_type; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.qualification_type (
    id integer NOT NULL,
    label character varying NOT NULL
);


ALTER TABLE public.qualification_type OWNER TO insertion;

--
-- Name: referent; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.referent (
    id integer NOT NULL,
    "beginDateReferent" date,
    "endDateReferent" date,
    "userId" integer
);


ALTER TABLE public.referent OWNER TO insertion;

--
-- Name: referent_history_id_seq; Type: SEQUENCE; Schema: public; Owner: insertion
--

CREATE SEQUENCE public.referent_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.referent_history_id_seq OWNER TO insertion;

--
-- Name: referent_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: insertion
--

ALTER SEQUENCE public.referent_history_id_seq OWNED BY public.referent_history.id;


--
-- Name: referent_id_seq; Type: SEQUENCE; Schema: public; Owner: insertion
--

CREATE SEQUENCE public.referent_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.referent_id_seq OWNER TO insertion;

--
-- Name: referent_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: insertion
--

ALTER SEQUENCE public.referent_id_seq OWNED BY public.referent.id;


--
-- Name: refresh_token; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.refresh_token (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "userId" integer NOT NULL,
    expires timestamp without time zone NOT NULL,
    revoked boolean DEFAULT false NOT NULL
);


ALTER TABLE public.refresh_token OWNER TO insertion;

--
-- Name: residential_address; Type: VIEW; Schema: public; Owner: insertion
--

CREATE VIEW public.residential_address AS
 SELECT b.id AS "beneficiaryId",
    ba.id,
    ba."beginDate",
    ba."endDate",
    ba.address,
    ba."additionalAddress",
    ba."postalCode",
    ba.city,
    ba."cliId",
    ba."ctmId",
    ba."qpvId",
    ba."residentialStatus",
    ba."residentialStatusComplement"
   FROM (public.beneficiary b
     LEFT JOIN public.beneficiary_address ba ON ((ba.id = b."residentialAddressId")));


ALTER TABLE public.residential_address OWNER TO insertion;

--
-- Name: residential_address_history; Type: VIEW; Schema: public; Owner: insertion
--

CREATE VIEW public.residential_address_history AS
 SELECT b."beneficiaryId",
    ba.id,
    ba."beginDate",
    ba."endDate",
    ba.address,
    ba."additionalAddress",
    ba."postalCode",
    ba.city,
    ba."cliId",
    ba."ctmId",
    ba."qpvId",
    ba."residentialStatus",
    ba."residentialStatusComplement"
   FROM (public.beneficiary_residential_history b
     LEFT JOIN public.beneficiary_address ba ON ((ba.id = b."beneficiaryAddressId")));


ALTER TABLE public.residential_address_history OWNER TO insertion;

--
-- Name: rsj; Type: VIEW; Schema: public; Owner: insertion
--

CREATE VIEW public.rsj AS
 SELECT i.id,
    i."instructionDate",
    i."directedByName",
    i."taxSituation",
    i.age_year,
    i.age_month,
        CASE
            WHEN (i.age_month > (0)::numeric) THEN concat(i.age_year, ' ans', ' et ', i.age_month, ' mois')
            ELSE concat(i.age_year, ' ans')
        END AS age,
    i."birthDate",
    i."familyQuotient",
    i."otherIncomePrecision",
    ( SELECT instruction_rsj_income."currentMonth"
           FROM public.instruction_rsj_income
          WHERE ((instruction_rsj_income."instructionRSJId" = i.id) AND ((instruction_rsj_income.type)::text = 'Professional'::text))
         LIMIT 1) AS "incomeProfessional",
    ( SELECT instruction_rsj_income."currentMonth"
           FROM public.instruction_rsj_income
          WHERE ((instruction_rsj_income."instructionRSJId" = i.id) AND ((instruction_rsj_income.type)::text = 'Replacement'::text))
         LIMIT 1) AS "incomeReplacement",
    ( SELECT instruction_rsj_income."currentMonth"
           FROM public.instruction_rsj_income
          WHERE ((instruction_rsj_income."instructionRSJId" = i.id) AND ((instruction_rsj_income.type)::text = 'Training'::text))
         LIMIT 1) AS "incomeTraining",
    ( SELECT instruction_rsj_income."currentMonth"
           FROM public.instruction_rsj_income
          WHERE ((instruction_rsj_income."instructionRSJId" = i.id) AND ((instruction_rsj_income.type)::text = 'SocialSupport'::text))
         LIMIT 1) AS "incomeSocialSupport",
    ( SELECT instruction_rsj_income."currentMonth"
           FROM public.instruction_rsj_income
          WHERE ((instruction_rsj_income."instructionRSJId" = i.id) AND ((instruction_rsj_income.type)::text = 'Other'::text))
         LIMIT 1) AS "incomeOther",
    ( SELECT sum(instruction_rsj_income."currentMonth") AS sum
           FROM public.instruction_rsj_income
          WHERE (instruction_rsj_income."instructionRSJId" = i.id)) AS "incomeTotal",
    ( SELECT instruction_rsj_income."nextMonth"
           FROM public.instruction_rsj_income
          WHERE ((instruction_rsj_income."instructionRSJId" = i.id) AND ((instruction_rsj_income.type)::text = 'Professional'::text))
         LIMIT 1) AS "incomeNextMonthProfessional",
    ( SELECT instruction_rsj_income."nextMonth"
           FROM public.instruction_rsj_income
          WHERE ((instruction_rsj_income."instructionRSJId" = i.id) AND ((instruction_rsj_income.type)::text = 'Replacement'::text))
         LIMIT 1) AS "incomeNextMonthReplacement",
    ( SELECT instruction_rsj_income."nextMonth"
           FROM public.instruction_rsj_income
          WHERE ((instruction_rsj_income."instructionRSJId" = i.id) AND ((instruction_rsj_income.type)::text = 'Training'::text))
         LIMIT 1) AS "incomeNextMonthTraining",
    ( SELECT instruction_rsj_income."nextMonth"
           FROM public.instruction_rsj_income
          WHERE ((instruction_rsj_income."instructionRSJId" = i.id) AND ((instruction_rsj_income.type)::text = 'SocialSupport'::text))
         LIMIT 1) AS "incomeNextMonthSocialSupport",
    ( SELECT instruction_rsj_income."nextMonth"
           FROM public.instruction_rsj_income
          WHERE ((instruction_rsj_income."instructionRSJId" = i.id) AND ((instruction_rsj_income.type)::text = 'Other'::text))
         LIMIT 1) AS "incomeNextMonthOther",
    ( SELECT sum(instruction_rsj_income."nextMonth") AS sum
           FROM public.instruction_rsj_income
          WHERE (instruction_rsj_income."instructionRSJId" = i.id)) AS "incomeNextMonthTotal",
    i."socialCareInProgress",
    i."socialStructureName",
    i."aseService",
    i."aseServiceLyon",
    i."rsaSimulation",
    i."complementaryHealth",
    i."givenUpCareInPast6Months",
    ( SELECT ba."qpvId"
           FROM (public.beneficiary_address ba
             LEFT JOIN public.instruction_rsj ir ON ((ir."residentialAddressId" = ba.id)))
          WHERE (ir.id = i.id)) AS "qPVId",
    i."individualInternetAccess",
    i."connectedToTCLNetwork",
    i."leisureAccessInPast12Months",
    ( SELECT ba."residentialStatus"
           FROM (public.beneficiary_address ba
             LEFT JOIN public.instruction_rsj ir ON ((ir."residentialAddressId" = ba.id)))
          WHERE (ir.id = i.id)) AS "residentialStatus",
    i."hostedFreeOfCharge",
    i."shelterRegistration",
    i."residentialSituationDuration",
    i."searchingForHousing",
    i."housingProcessStarted",
    i."housingProcessWithHelp",
    i."housingProcessWithHelpBy",
    i."beneficiaryId"
   FROM ( SELECT instruction_rsj.id,
            instruction_rsj."instructionDate",
            instruction_rsj."taxSituation",
            instruction_rsj."directedByName",
            EXTRACT(month FROM age((instruction_rsj."instructionDate")::timestamp with time zone, (instruction_rsj."birthDate")::timestamp with time zone)) AS age_month,
            EXTRACT(year FROM age((instruction_rsj."instructionDate")::timestamp with time zone, (instruction_rsj."birthDate")::timestamp with time zone)) AS age_year,
            instruction_rsj."birthDate",
            instruction_rsj."familyQuotient",
            instruction_rsj."otherIncomePrecision",
            instruction_rsj."socialCareInProgress",
            instruction_rsj."socialStructureName",
            instruction_rsj."aseService",
            instruction_rsj."aseServiceLyon",
            instruction_rsj."rsaSimulation",
            instruction_rsj."complementaryHealth",
            instruction_rsj."givenUpCareInPast6Months",
            instruction_rsj."individualInternetAccess",
            instruction_rsj."connectedToTCLNetwork",
            instruction_rsj."leisureAccessInPast12Months",
            instruction_rsj."hostedFreeOfCharge",
            instruction_rsj."shelterRegistration",
            instruction_rsj."residentialSituationDuration",
            instruction_rsj."searchingForHousing",
            instruction_rsj."housingProcessStarted",
            instruction_rsj."housingProcessWithHelp",
            instruction_rsj."housingProcessWithHelpBy",
            instruction_rsj."beneficiaryId"
           FROM public.instruction_rsj) i;


ALTER TABLE public.rsj OWNER TO insertion;

--
-- Name: rsj_mobilized_plan; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.rsj_mobilized_plan (
    id integer NOT NULL,
    label character varying NOT NULL
);


ALTER TABLE public.rsj_mobilized_plan OWNER TO insertion;

--
-- Name: rsj_payment; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.rsj_payment (
    id integer NOT NULL,
    "paymentDataId" integer NOT NULL,
    "beneficiaryRsjId" integer NOT NULL,
    "instructionRsjId" integer NOT NULL,
    "stateDate" date NOT NULL,
    "stateId" integer NOT NULL,
    amount numeric NOT NULL,
    "paymentMonth" date NOT NULL
);


ALTER TABLE public.rsj_payment OWNER TO insertion;

--
-- Name: rsj_payment_data_id_seq; Type: SEQUENCE; Schema: public; Owner: insertion
--

CREATE SEQUENCE public.rsj_payment_data_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rsj_payment_data_id_seq OWNER TO insertion;

--
-- Name: rsj_payment_data; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.rsj_payment_data (
    id integer DEFAULT nextval('public.rsj_payment_data_id_seq'::regclass) NOT NULL,
    "beginDate" date NOT NULL,
    "endDate" date,
    "holderFirstName" character varying NOT NULL,
    "holderLastName" character varying NOT NULL,
    "bankName" character varying NOT NULL,
    iban character varying NOT NULL,
    bic character varying NOT NULL,
    "livretA" boolean NOT NULL,
    "ribId" integer NOT NULL
);


ALTER TABLE public.rsj_payment_data OWNER TO insertion;

--
-- Name: rsj_payment_id_seq; Type: SEQUENCE; Schema: public; Owner: insertion
--

CREATE SEQUENCE public.rsj_payment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rsj_payment_id_seq OWNER TO insertion;

--
-- Name: rsj_payment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: insertion
--

ALTER SEQUENCE public.rsj_payment_id_seq OWNED BY public.rsj_payment.id;


--
-- Name: rsj_payment_state; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.rsj_payment_state (
    id integer NOT NULL,
    label character varying NOT NULL
);


ALTER TABLE public.rsj_payment_state OWNER TO insertion;

--
-- Name: rsj_payment_state_id_seq; Type: SEQUENCE; Schema: public; Owner: insertion
--

CREATE SEQUENCE public.rsj_payment_state_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rsj_payment_state_id_seq OWNER TO insertion;

--
-- Name: rsj_payment_state_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: insertion
--

ALTER SEQUENCE public.rsj_payment_state_id_seq OWNED BY public.rsj_payment_state.id;


--
-- Name: rsj_reason; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.rsj_reason (
    id integer NOT NULL,
    label character varying NOT NULL
);


ALTER TABLE public.rsj_reason OWNER TO insertion;

--
-- Name: user; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public."user" (
    id integer NOT NULL,
    email character varying NOT NULL,
    name character varying NOT NULL,
    firstname character varying NOT NULL,
    lastname character varying NOT NULL,
    "structureId" integer,
    "cliId" integer,
    active boolean DEFAULT true NOT NULL,
    department boolean DEFAULT false NOT NULL,
    "passwordHash" character varying,
    "passwordSalt" character varying,
    "resetPasswordToken" character varying,
    "resetPasswordTokenExpiry" timestamp without time zone
);


ALTER TABLE public."user" OWNER TO insertion;

--
-- Name: rsj_referent; Type: VIEW; Schema: public; Owner: insertion
--

CREATE VIEW public.rsj_referent AS
 SELECT r.id,
    r."beginDateReferent",
    r."endDateReferent",
    r."userId",
    u."structureId",
    br.id AS "beneficiaryRsjId"
   FROM ((public.referent r
     LEFT JOIN public.beneficiary_rsj br ON ((r.id = br."referentId")))
     LEFT JOIN public."user" u ON ((u.id = r."userId")))
  WHERE (r.id = br."referentId");


ALTER TABLE public.rsj_referent OWNER TO insertion;

--
-- Name: rsj_referent_history; Type: VIEW; Schema: public; Owner: insertion
--

CREATE VIEW public.rsj_referent_history AS
 SELECT brrh."referentId" AS id,
    r."beginDateReferent",
    r."endDateReferent",
    r."userId",
    u."structureId",
    brrh."beneficiaryRsjId"
   FROM ((public.beneficiary_rsj_referent_history brrh
     LEFT JOIN public.referent r ON ((r.id = brrh."referentId")))
     LEFT JOIN public."user" u ON ((u.id = r."userId")));


ALTER TABLE public.rsj_referent_history OWNER TO insertion;

--
-- Name: rsj_situation; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.rsj_situation (
    id integer NOT NULL,
    label character varying NOT NULL
);


ALTER TABLE public.rsj_situation OWNER TO insertion;

--
-- Name: rsj_state; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.rsj_state (
    id integer NOT NULL,
    label character varying NOT NULL
);


ALTER TABLE public.rsj_state OWNER TO insertion;

--
-- Name: sector; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.sector (
    id integer NOT NULL,
    label character varying NOT NULL,
    "codeRome" character varying
);


ALTER TABLE public.sector OWNER TO insertion;

--
-- Name: session; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.session (
    id integer NOT NULL,
    "communityActionId" integer NOT NULL,
    "refereeId" integer NOT NULL,
    "coReferee" character varying,
    location character varying NOT NULL,
    "seatsNumber" integer NOT NULL,
    "extraInformation" character varying,
    "isIER" boolean DEFAULT false NOT NULL,
    geotag character varying
);


ALTER TABLE public.session OWNER TO insertion;

--
-- Name: session_id_seq; Type: SEQUENCE; Schema: public; Owner: insertion
--

CREATE SEQUENCE public.session_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.session_id_seq OWNER TO insertion;

--
-- Name: session_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: insertion
--

ALTER SEQUENCE public.session_id_seq OWNED BY public.session.id;


--
-- Name: signature; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.signature (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "userId" integer,
    "signatureData" bytea NOT NULL,
    "createdDate" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedDate" timestamp without time zone DEFAULT now() NOT NULL,
    "contractId" integer,
    "contractIerId" integer,
    "instructionRsjId" integer
);


ALTER TABLE public.signature OWNER TO insertion;

--
-- Name: stage; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.stage (
    id integer NOT NULL,
    label character varying,
    "beginDate" date NOT NULL,
    "endDate" date NOT NULL,
    "stageState" character varying NOT NULL,
    organization character varying,
    comment character varying,
    "reasonEndStage" character varying,
    "beneficiaryId" integer NOT NULL,
    "stageNatureTypeId" integer NOT NULL,
    "structureId" integer NOT NULL,
    "organizationStructureId" integer,
    "enrolId" integer,
    duration integer,
    "communityActionId" integer
);


ALTER TABLE public.stage OWNER TO insertion;

--
-- Name: stage_id_seq; Type: SEQUENCE; Schema: public; Owner: insertion
--

CREATE SEQUENCE public.stage_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.stage_id_seq OWNER TO insertion;

--
-- Name: stage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: insertion
--

ALTER SEQUENCE public.stage_id_seq OWNED BY public.stage.id;


--
-- Name: stage_nature_type; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.stage_nature_type (
    id integer NOT NULL,
    nature character varying NOT NULL,
    type character varying NOT NULL,
    category character varying DEFAULT 'Autres'::character varying NOT NULL
);


ALTER TABLE public.stage_nature_type OWNER TO insertion;

--
-- Name: stage_nature_type_id_seq; Type: SEQUENCE; Schema: public; Owner: insertion
--

CREATE SEQUENCE public.stage_nature_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.stage_nature_type_id_seq OWNER TO insertion;

--
-- Name: stage_nature_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: insertion
--

ALTER SEQUENCE public.stage_nature_type_id_seq OWNED BY public.stage_nature_type.id;


--
-- Name: stage_support_type; Type: VIEW; Schema: public; Owner: insertion
--

CREATE VIEW public.stage_support_type AS
 SELECT s.id,
    s.label,
    s."beginDate",
    s."endDate",
    s."stageState",
    s.organization,
    s.comment,
    s."reasonEndStage",
    s."beneficiaryId",
    s."stageNatureTypeId",
    s."structureId",
    s."organizationStructureId",
    s."enrolId",
    s.duration,
    s."communityActionId",
    ast."supportTypeId"
   FROM (public.stage s
     LEFT JOIN public.aggregate_support_type ast ON (((s."beneficiaryId" = ast."beneficiaryId") AND (((s."beginDate" >= ast."beginDate") AND (s."beginDate" <= ast."endDate")) OR ((s."endDate" >= ast."beginDate") AND (s."endDate" <= ast."endDate")) OR ((ast."endDate" IS NULL) AND (ast."beginDate" <= s."beginDate"))))));


ALTER TABLE public.stage_support_type OWNER TO insertion;

--
-- Name: structure; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.structure (
    id integer NOT NULL,
    "idIODAS" character varying NOT NULL,
    label character varying NOT NULL,
    address character varying NOT NULL,
    "additionalAddress" character varying,
    "postalCode" character varying NOT NULL,
    city character varying NOT NULL,
    active boolean NOT NULL,
    phone character varying,
    "SIRET" character varying,
    "logoId" integer,
    "contactEmail" character varying,
    website character varying,
    presentation character varying,
    geotag character varying
);


ALTER TABLE public.structure OWNER TO insertion;

--
-- Name: structure_focus_area; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.structure_focus_area (
    "structureId" integer NOT NULL,
    "focusAreaId" integer NOT NULL
);


ALTER TABLE public.structure_focus_area OWNER TO insertion;

--
-- Name: structure_id_seq; Type: SEQUENCE; Schema: public; Owner: insertion
--

CREATE SEQUENCE public.structure_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.structure_id_seq OWNER TO insertion;

--
-- Name: structure_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: insertion
--

ALTER SEQUENCE public.structure_id_seq OWNED BY public.structure.id;


--
-- Name: structure_to_area; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.structure_to_area (
    "cliId" integer NOT NULL,
    "structureId" integer NOT NULL,
    "supportTypeId" integer NOT NULL,
    "placesNumber" integer NOT NULL
);


ALTER TABLE public.structure_to_area OWNER TO insertion;

--
-- Name: support_history_id_seq; Type: SEQUENCE; Schema: public; Owner: insertion
--

CREATE SEQUENCE public.support_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.support_history_id_seq OWNER TO insertion;

--
-- Name: support_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: insertion
--

ALTER SEQUENCE public.support_history_id_seq OWNED BY public.support_history.id;


--
-- Name: support_type; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.support_type (
    id integer NOT NULL,
    label character varying NOT NULL
);


ALTER TABLE public.support_type OWNER TO insertion;

--
-- Name: survey_fse_id_seq; Type: SEQUENCE; Schema: public; Owner: insertion
--

CREATE SEQUENCE public.survey_fse_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.survey_fse_id_seq OWNER TO insertion;

--
-- Name: survey_fse_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: insertion
--

ALTER SEQUENCE public.survey_fse_id_seq OWNED BY public.survey_fse.id;


--
-- Name: town; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.town (
    "codeInsee" character varying NOT NULL,
    denomination character varying NOT NULL,
    "postalCode" character varying NOT NULL,
    "ctmId" integer
);


ALTER TABLE public.town OWNER TO insertion;

--
-- Name: traceability; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.traceability (
    id integer NOT NULL,
    "statusDate" date NOT NULL,
    status character varying NOT NULL,
    comment character varying,
    "performedBy" character varying,
    "contractId" integer,
    "contractIerId" integer,
    "instructionRsjId" integer
);


ALTER TABLE public.traceability OWNER TO insertion;

--
-- Name: traceability_id_seq; Type: SEQUENCE; Schema: public; Owner: insertion
--

CREATE SEQUENCE public.traceability_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.traceability_id_seq OWNER TO insertion;

--
-- Name: traceability_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: insertion
--

ALTER SEQUENCE public.traceability_id_seq OWNED BY public.traceability.id;


--
-- Name: training_area; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.training_area (
    id integer NOT NULL,
    label character varying NOT NULL
);


ALTER TABLE public.training_area OWNER TO insertion;

--
-- Name: transport_mode; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.transport_mode (
    id integer NOT NULL,
    label character varying NOT NULL
);


ALTER TABLE public.transport_mode OWNER TO insertion;

--
-- Name: transport_mode_id_seq; Type: SEQUENCE; Schema: public; Owner: insertion
--

CREATE SEQUENCE public.transport_mode_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.transport_mode_id_seq OWNER TO insertion;

--
-- Name: transport_mode_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: insertion
--

ALTER SEQUENCE public.transport_mode_id_seq OWNED BY public.transport_mode.id;


--
-- Name: user_address; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.user_address (
    id integer NOT NULL,
    main character varying NOT NULL,
    complement character varying,
    "postalCode" character varying NOT NULL,
    city character varying NOT NULL,
    phone character varying,
    "employeeType" character varying,
    "userId" integer NOT NULL
);


ALTER TABLE public.user_address OWNER TO insertion;

--
-- Name: user_address_id_seq; Type: SEQUENCE; Schema: public; Owner: insertion
--

CREATE SEQUENCE public.user_address_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_address_id_seq OWNER TO insertion;

--
-- Name: user_address_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: insertion
--

ALTER SEQUENCE public.user_address_id_seq OWNED BY public.user_address.id;


--
-- Name: user_ctm; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.user_ctm (
    "userId" integer NOT NULL,
    "ctmId" integer NOT NULL
);


ALTER TABLE public.user_ctm OWNER TO insertion;

--
-- Name: user_group; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.user_group (
    "userId" integer NOT NULL,
    "groupName" character varying NOT NULL
);


ALTER TABLE public.user_group OWNER TO insertion;

--
-- Name: user_id_seq; Type: SEQUENCE; Schema: public; Owner: insertion
--

CREATE SEQUENCE public.user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_id_seq OWNER TO insertion;

--
-- Name: user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: insertion
--

ALTER SEQUENCE public.user_id_seq OWNED BY public."user".id;


--
-- Name: user_notification; Type: TABLE; Schema: public; Owner: insertion
--

CREATE TABLE public.user_notification (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "notificationDate" timestamp with time zone DEFAULT now() NOT NULL,
    "notificationType" integer NOT NULL,
    title character varying,
    message character varying NOT NULL
);


ALTER TABLE public.user_notification OWNER TO insertion;

--
-- Name: user_notification_id_seq; Type: SEQUENCE; Schema: public; Owner: insertion
--

CREATE SEQUENCE public.user_notification_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_notification_id_seq OWNER TO insertion;

--
-- Name: user_notification_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: insertion
--

ALTER SEQUENCE public.user_notification_id_seq OWNED BY public.user_notification.id;


--
-- Name: agenda_event id; Type: DEFAULT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.agenda_event ALTER COLUMN id SET DEFAULT nextval('public.agenda_event_id_seq'::regclass);


--
-- Name: beneficiary id; Type: DEFAULT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.beneficiary ALTER COLUMN id SET DEFAULT nextval('public.beneficiary_id_seq'::regclass);


--
-- Name: beneficiary_address id; Type: DEFAULT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.beneficiary_address ALTER COLUMN id SET DEFAULT nextval('public.beneficiary_address_id_seq'::regclass);


--
-- Name: beneficiary_complement id; Type: DEFAULT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.beneficiary_complement ALTER COLUMN id SET DEFAULT nextval('public.beneficiary_complement_id_seq'::regclass);


--
-- Name: beneficiary_employment id; Type: DEFAULT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.beneficiary_employment ALTER COLUMN id SET DEFAULT nextval('public.beneficiary_employment_id_seq'::regclass);


--
-- Name: children id; Type: DEFAULT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.children ALTER COLUMN id SET DEFAULT nextval('public.children_id_seq'::regclass);


--
-- Name: community_action id; Type: DEFAULT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.community_action ALTER COLUMN id SET DEFAULT nextval('public.community_action_id_seq'::regclass);


--
-- Name: contract id; Type: DEFAULT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.contract ALTER COLUMN id SET DEFAULT nextval('public.contract_id_seq'::regclass);


--
-- Name: contract_ier id; Type: DEFAULT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.contract_ier ALTER COLUMN id SET DEFAULT nextval('public.contract_ier_id_seq'::regclass);


--
-- Name: course id; Type: DEFAULT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.course ALTER COLUMN id SET DEFAULT nextval('public.course_id_seq'::regclass);


--
-- Name: custom_query id; Type: DEFAULT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.custom_query ALTER COLUMN id SET DEFAULT nextval('public.custom_query_id_seq'::regclass);


--
-- Name: dashboard_counter id; Type: DEFAULT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.dashboard_counter ALTER COLUMN id SET DEFAULT nextval('public.dashboard_counter_id_seq'::regclass);


--
-- Name: diagnostic id; Type: DEFAULT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.diagnostic ALTER COLUMN id SET DEFAULT nextval('public.diagnostic_id_seq'::regclass);


--
-- Name: diagnostic_barrier id; Type: DEFAULT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.diagnostic_barrier ALTER COLUMN id SET DEFAULT nextval('public.diagnostic_barrier_id_seq'::regclass);


--
-- Name: diagnostic_qualification_type id; Type: DEFAULT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.diagnostic_qualification_type ALTER COLUMN id SET DEFAULT nextval('public.diagnostic_qualification_type_id_seq'::regclass);


--
-- Name: document id; Type: DEFAULT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.document ALTER COLUMN id SET DEFAULT nextval('public.document_id_seq'::regclass);


--
-- Name: domain id; Type: DEFAULT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.domain ALTER COLUMN id SET DEFAULT nextval('public.domain_id_seq'::regclass);


--
-- Name: employment_asset id; Type: DEFAULT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.employment_asset ALTER COLUMN id SET DEFAULT nextval('public.employment_asset_id_seq'::regclass);


--
-- Name: employment_barrier id; Type: DEFAULT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.employment_barrier ALTER COLUMN id SET DEFAULT nextval('public.employment_barrier_id_seq'::regclass);


--
-- Name: employment_qualification_type id; Type: DEFAULT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.employment_qualification_type ALTER COLUMN id SET DEFAULT nextval('public.employment_qualification_type_id_seq'::regclass);


--
-- Name: employment_transport_mode id; Type: DEFAULT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.employment_transport_mode ALTER COLUMN id SET DEFAULT nextval('public.employment_transport_mode_id_seq'::regclass);


--
-- Name: enrol id; Type: DEFAULT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.enrol ALTER COLUMN id SET DEFAULT nextval('public.enrol_id_seq'::regclass);


--
-- Name: formation id; Type: DEFAULT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.formation ALTER COLUMN id SET DEFAULT nextval('public.formation_id_seq'::regclass);


--
-- Name: home id; Type: DEFAULT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.home ALTER COLUMN id SET DEFAULT nextval('public.home_id_seq'::regclass);


--
-- Name: instruction_rsj id; Type: DEFAULT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.instruction_rsj ALTER COLUMN id SET DEFAULT nextval('public.instruction_rsj_id_seq'::regclass);


--
-- Name: instruction_rsj_income id; Type: DEFAULT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.instruction_rsj_income ALTER COLUMN id SET DEFAULT nextval('public.instruction_rsj_income_id_seq'::regclass);


--
-- Name: interview id; Type: DEFAULT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.interview ALTER COLUMN id SET DEFAULT nextval('public.interview_id_seq'::regclass);


--
-- Name: interview_theme id; Type: DEFAULT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.interview_theme ALTER COLUMN id SET DEFAULT nextval('public.interview_theme_id_seq'::regclass);


--
-- Name: job id; Type: DEFAULT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.job ALTER COLUMN id SET DEFAULT nextval('public.job_id_seq'::regclass);


--
-- Name: log id; Type: DEFAULT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.log ALTER COLUMN id SET DEFAULT nextval('public.log_id_seq'::regclass);


--
-- Name: logo id; Type: DEFAULT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.logo ALTER COLUMN id SET DEFAULT nextval('public.logo_id_seq'::regclass);


--
-- Name: orientation_history id; Type: DEFAULT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.orientation_history ALTER COLUMN id SET DEFAULT nextval('public.orientation_history_id_seq'::regclass);


--
-- Name: qpv id; Type: DEFAULT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.qpv ALTER COLUMN id SET DEFAULT nextval('public.qpv_id_seq'::regclass);


--
-- Name: referent id; Type: DEFAULT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.referent ALTER COLUMN id SET DEFAULT nextval('public.referent_id_seq'::regclass);


--
-- Name: referent_history id; Type: DEFAULT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.referent_history ALTER COLUMN id SET DEFAULT nextval('public.referent_history_id_seq'::regclass);


--
-- Name: rsj_payment id; Type: DEFAULT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.rsj_payment ALTER COLUMN id SET DEFAULT nextval('public.rsj_payment_id_seq'::regclass);


--
-- Name: rsj_payment_state id; Type: DEFAULT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.rsj_payment_state ALTER COLUMN id SET DEFAULT nextval('public.rsj_payment_state_id_seq'::regclass);


--
-- Name: session id; Type: DEFAULT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.session ALTER COLUMN id SET DEFAULT nextval('public.session_id_seq'::regclass);


--
-- Name: stage id; Type: DEFAULT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.stage ALTER COLUMN id SET DEFAULT nextval('public.stage_id_seq'::regclass);


--
-- Name: stage_nature_type id; Type: DEFAULT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.stage_nature_type ALTER COLUMN id SET DEFAULT nextval('public.stage_nature_type_id_seq'::regclass);


--
-- Name: structure id; Type: DEFAULT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.structure ALTER COLUMN id SET DEFAULT nextval('public.structure_id_seq'::regclass);


--
-- Name: support_history id; Type: DEFAULT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.support_history ALTER COLUMN id SET DEFAULT nextval('public.support_history_id_seq'::regclass);


--
-- Name: survey_fse id; Type: DEFAULT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.survey_fse ALTER COLUMN id SET DEFAULT nextval('public.survey_fse_id_seq'::regclass);


--
-- Name: traceability id; Type: DEFAULT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.traceability ALTER COLUMN id SET DEFAULT nextval('public.traceability_id_seq'::regclass);


--
-- Name: transport_mode id; Type: DEFAULT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.transport_mode ALTER COLUMN id SET DEFAULT nextval('public.transport_mode_id_seq'::regclass);


--
-- Name: user id; Type: DEFAULT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public."user" ALTER COLUMN id SET DEFAULT nextval('public.user_id_seq'::regclass);


--
-- Name: user_address id; Type: DEFAULT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.user_address ALTER COLUMN id SET DEFAULT nextval('public.user_address_id_seq'::regclass);


--
-- Name: user_notification id; Type: DEFAULT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.user_notification ALTER COLUMN id SET DEFAULT nextval('public.user_notification_id_seq'::regclass);


--
-- Data for Name: access_token; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4421.dat

--
-- Data for Name: address; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4375.dat

--
-- Data for Name: agenda_event; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4356.dat

--
-- Data for Name: asset; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4339.dat

--
-- Data for Name: barrier; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4327.dat

--
-- Data for Name: beneficiary; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4346.dat

--
-- Data for Name: beneficiary_address; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4434.dat

--
-- Data for Name: beneficiary_complement; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4320.dat

--
-- Data for Name: beneficiary_employment; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4338.dat

--
-- Data for Name: beneficiary_employment_jobs_job; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4357.dat

--
-- Data for Name: beneficiary_postal_history; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4440.dat

--
-- Data for Name: beneficiary_residential_history; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4439.dat

--
-- Data for Name: beneficiary_rsj; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4438.dat

--
-- Data for Name: beneficiary_rsj_payment_data_history; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4450.dat

--
-- Data for Name: beneficiary_rsj_referent_history; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4443.dat

--
-- Data for Name: children; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4383.dat

--
-- Data for Name: clearance; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4418.dat

--
-- Data for Name: clearance_category; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4417.dat

--
-- Data for Name: clearance_group; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4420.dat

--
-- Data for Name: clearance_user; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4419.dat

--
-- Data for Name: cli; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4315.dat

--
-- Data for Name: community_action; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4379.dat

--
-- Data for Name: contract; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4322.dat

--
-- Data for Name: contract_ier; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4381.dat

--
-- Data for Name: course; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4393.dat

--
-- Data for Name: ctm; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4316.dat

--
-- Data for Name: custom_query; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4403.dat

--
-- Data for Name: dashboard_counter; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4426.dat

--
-- Data for Name: degree; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4323.dat

--
-- Data for Name: diagnostic; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4391.dat

--
-- Data for Name: diagnostic_barrier; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4385.dat

--
-- Data for Name: diagnostic_qualification_type; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4387.dat

--
-- Data for Name: document; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4359.dat

--
-- Data for Name: document_status; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4361.dat

--
-- Data for Name: document_title; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4360.dat

--
-- Data for Name: domain; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4430.dat

--
-- Data for Name: employment_asset; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4341.dat

--
-- Data for Name: employment_barrier; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4329.dat

--
-- Data for Name: employment_qualification_type; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4326.dat

--
-- Data for Name: employment_training_area; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4343.dat

--
-- Data for Name: employment_transport_mode; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4336.dat

--
-- Data for Name: enrol; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4397.dat

--
-- Data for Name: focus_area; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4431.dat

--
-- Data for Name: formation; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4389.dat

--
-- Data for Name: group; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4364.dat

--
-- Data for Name: health_insurance; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4411.dat

--
-- Data for Name: home; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4372.dat

--
-- Data for Name: instruction_rsj; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4405.dat

--
-- Data for Name: instruction_rsj_income; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4407.dat

--
-- Data for Name: instruction_rsj_mobilized_plan; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4415.dat

--
-- Data for Name: instruction_rsj_non_renewal; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4408.dat

--
-- Data for Name: instruction_rsj_other_document; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4410.dat

--
-- Data for Name: instruction_rsj_situation; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4414.dat

--
-- Data for Name: instruction_rsj_use_title; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4409.dat

--
-- Data for Name: interview; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4354.dat

--
-- Data for Name: interview_theme; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4352.dat

--
-- Data for Name: job; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4331.dat

--
-- Data for Name: job_type; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4342.dat

--
-- Data for Name: log; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4370.dat

--
-- Data for Name: logo; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4377.dat

--
-- Data for Name: metropole_town; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4374.dat

--
-- Data for Name: orientation_history; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4312.dat

--
-- Data for Name: qpv; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4318.dat

--
-- Data for Name: qualification_type; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4324.dat

--
-- Data for Name: referent; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4442.dat

--
-- Data for Name: referent_history; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4399.dat

--
-- Data for Name: refresh_token; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4422.dat

--
-- Data for Name: rsj_mobilized_plan; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4413.dat

--
-- Data for Name: rsj_payment; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4445.dat

--
-- Data for Name: rsj_payment_data; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4449.dat

--
-- Data for Name: rsj_payment_state; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4447.dat

--
-- Data for Name: rsj_reason; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4435.dat

--
-- Data for Name: rsj_situation; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4412.dat

--
-- Data for Name: rsj_state; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4436.dat

--
-- Data for Name: sector; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4344.dat

--
-- Data for Name: session; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4395.dat

--
-- Data for Name: signature; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4416.dat

--
-- Data for Name: stage; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4350.dat

--
-- Data for Name: stage_nature_type; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4348.dat

--
-- Data for Name: structure; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4308.dat

--
-- Data for Name: structure_focus_area; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4432.dat

--
-- Data for Name: structure_to_area; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4314.dat

--
-- Data for Name: support_history; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4310.dat

--
-- Data for Name: support_type; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4313.dat

--
-- Data for Name: survey_fse; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4368.dat

--
-- Data for Name: town; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4373.dat

--
-- Data for Name: traceability; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4424.dat

--
-- Data for Name: training_area; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4332.dat

--
-- Data for Name: transport_mode; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4334.dat

--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4363.dat

--
-- Data for Name: user_address; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4401.dat

--
-- Data for Name: user_ctm; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4365.dat

--
-- Data for Name: user_group; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4366.dat

--
-- Data for Name: user_notification; Type: TABLE DATA; Schema: public; Owner: insertion
--

\i $$PATH$$/4428.dat

--
-- Name: agenda_event_id_seq; Type: SEQUENCE SET; Schema: public; Owner: insertion
--

SELECT pg_catalog.setval('public.agenda_event_id_seq', 1, false);


--
-- Name: beneficiary_address_id_seq; Type: SEQUENCE SET; Schema: public; Owner: insertion
--

SELECT pg_catalog.setval('public.beneficiary_address_id_seq', 57, true);


--
-- Name: beneficiary_complement_id_seq; Type: SEQUENCE SET; Schema: public; Owner: insertion
--

SELECT pg_catalog.setval('public.beneficiary_complement_id_seq', 54, true);


--
-- Name: beneficiary_employment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: insertion
--

SELECT pg_catalog.setval('public.beneficiary_employment_id_seq', 54, true);


--
-- Name: beneficiary_id_seq; Type: SEQUENCE SET; Schema: public; Owner: insertion
--

SELECT pg_catalog.setval('public.beneficiary_id_seq', 59, true);


--
-- Name: beneficiary_rsj_id_seq; Type: SEQUENCE SET; Schema: public; Owner: insertion
--

SELECT pg_catalog.setval('public.beneficiary_rsj_id_seq', 384, true);


--
-- Name: children_id_seq; Type: SEQUENCE SET; Schema: public; Owner: insertion
--

SELECT pg_catalog.setval('public.children_id_seq', 1, false);


--
-- Name: community_action_id_seq; Type: SEQUENCE SET; Schema: public; Owner: insertion
--

SELECT pg_catalog.setval('public.community_action_id_seq', 1, false);


--
-- Name: contract_id_seq; Type: SEQUENCE SET; Schema: public; Owner: insertion
--

SELECT pg_catalog.setval('public.contract_id_seq', 1, false);


--
-- Name: contract_ier_id_seq; Type: SEQUENCE SET; Schema: public; Owner: insertion
--

SELECT pg_catalog.setval('public.contract_ier_id_seq', 1, false);


--
-- Name: course_id_seq; Type: SEQUENCE SET; Schema: public; Owner: insertion
--

SELECT pg_catalog.setval('public.course_id_seq', 1, false);


--
-- Name: custom_query_id_seq; Type: SEQUENCE SET; Schema: public; Owner: insertion
--

SELECT pg_catalog.setval('public.custom_query_id_seq', 1, false);


--
-- Name: dashboard_counter_id_seq; Type: SEQUENCE SET; Schema: public; Owner: insertion
--

SELECT pg_catalog.setval('public.dashboard_counter_id_seq', 1, false);


--
-- Name: diagnostic_barrier_id_seq; Type: SEQUENCE SET; Schema: public; Owner: insertion
--

SELECT pg_catalog.setval('public.diagnostic_barrier_id_seq', 1, false);


--
-- Name: diagnostic_id_seq; Type: SEQUENCE SET; Schema: public; Owner: insertion
--

SELECT pg_catalog.setval('public.diagnostic_id_seq', 1, false);


--
-- Name: diagnostic_qualification_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: insertion
--

SELECT pg_catalog.setval('public.diagnostic_qualification_type_id_seq', 1, false);


--
-- Name: document_id_seq; Type: SEQUENCE SET; Schema: public; Owner: insertion
--

SELECT pg_catalog.setval('public.document_id_seq', 427, true);


--
-- Name: domain_id_seq; Type: SEQUENCE SET; Schema: public; Owner: insertion
--

SELECT pg_catalog.setval('public.domain_id_seq', 1, false);


--
-- Name: employment_asset_id_seq; Type: SEQUENCE SET; Schema: public; Owner: insertion
--

SELECT pg_catalog.setval('public.employment_asset_id_seq', 1, false);


--
-- Name: employment_barrier_id_seq; Type: SEQUENCE SET; Schema: public; Owner: insertion
--

SELECT pg_catalog.setval('public.employment_barrier_id_seq', 1, false);


--
-- Name: employment_qualification_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: insertion
--

SELECT pg_catalog.setval('public.employment_qualification_type_id_seq', 1, false);


--
-- Name: employment_transport_mode_id_seq; Type: SEQUENCE SET; Schema: public; Owner: insertion
--

SELECT pg_catalog.setval('public.employment_transport_mode_id_seq', 1, false);


--
-- Name: enrol_id_seq; Type: SEQUENCE SET; Schema: public; Owner: insertion
--

SELECT pg_catalog.setval('public.enrol_id_seq', 1, false);


--
-- Name: formation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: insertion
--

SELECT pg_catalog.setval('public.formation_id_seq', 1, false);


--
-- Name: home_id_seq; Type: SEQUENCE SET; Schema: public; Owner: insertion
--

SELECT pg_catalog.setval('public.home_id_seq', 1, false);


--
-- Name: instruction_rsj_id_seq; Type: SEQUENCE SET; Schema: public; Owner: insertion
--

SELECT pg_catalog.setval('public.instruction_rsj_id_seq', 4, true);


--
-- Name: instruction_rsj_income_id_seq; Type: SEQUENCE SET; Schema: public; Owner: insertion
--

SELECT pg_catalog.setval('public.instruction_rsj_income_id_seq', 1, false);


--
-- Name: interview_id_seq; Type: SEQUENCE SET; Schema: public; Owner: insertion
--

SELECT pg_catalog.setval('public.interview_id_seq', 1, false);


--
-- Name: interview_theme_id_seq; Type: SEQUENCE SET; Schema: public; Owner: insertion
--

SELECT pg_catalog.setval('public.interview_theme_id_seq', 14, true);


--
-- Name: job_id_seq; Type: SEQUENCE SET; Schema: public; Owner: insertion
--

SELECT pg_catalog.setval('public.job_id_seq', 1, false);


--
-- Name: log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: insertion
--

SELECT pg_catalog.setval('public.log_id_seq', 1, false);


--
-- Name: logo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: insertion
--

SELECT pg_catalog.setval('public.logo_id_seq', 1, false);


--
-- Name: orientation_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: insertion
--

SELECT pg_catalog.setval('public.orientation_history_id_seq', 1, false);


--
-- Name: qpv_id_seq; Type: SEQUENCE SET; Schema: public; Owner: insertion
--

SELECT pg_catalog.setval('public.qpv_id_seq', 59, true);


--
-- Name: referent_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: insertion
--

SELECT pg_catalog.setval('public.referent_history_id_seq', 1, false);


--
-- Name: referent_id_seq; Type: SEQUENCE SET; Schema: public; Owner: insertion
--

SELECT pg_catalog.setval('public.referent_id_seq', 1, false);


--
-- Name: rsj_payment_data_id_seq; Type: SEQUENCE SET; Schema: public; Owner: insertion
--

SELECT pg_catalog.setval('public.rsj_payment_data_id_seq', 146, true);


--
-- Name: rsj_payment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: insertion
--

SELECT pg_catalog.setval('public.rsj_payment_id_seq', 180, true);


--
-- Name: rsj_payment_state_id_seq; Type: SEQUENCE SET; Schema: public; Owner: insertion
--

SELECT pg_catalog.setval('public.rsj_payment_state_id_seq', 1, false);


--
-- Name: session_id_seq; Type: SEQUENCE SET; Schema: public; Owner: insertion
--

SELECT pg_catalog.setval('public.session_id_seq', 1, false);


--
-- Name: stage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: insertion
--

SELECT pg_catalog.setval('public.stage_id_seq', 1, false);


--
-- Name: stage_nature_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: insertion
--

SELECT pg_catalog.setval('public.stage_nature_type_id_seq', 1, false);


--
-- Name: structure_id_seq; Type: SEQUENCE SET; Schema: public; Owner: insertion
--

SELECT pg_catalog.setval('public.structure_id_seq', 1, false);


--
-- Name: support_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: insertion
--

SELECT pg_catalog.setval('public.support_history_id_seq', 1, false);


--
-- Name: survey_fse_id_seq; Type: SEQUENCE SET; Schema: public; Owner: insertion
--

SELECT pg_catalog.setval('public.survey_fse_id_seq', 1, false);


--
-- Name: traceability_id_seq; Type: SEQUENCE SET; Schema: public; Owner: insertion
--

SELECT pg_catalog.setval('public.traceability_id_seq', 142, true);


--
-- Name: transport_mode_id_seq; Type: SEQUENCE SET; Schema: public; Owner: insertion
--

SELECT pg_catalog.setval('public.transport_mode_id_seq', 1, false);


--
-- Name: user_address_id_seq; Type: SEQUENCE SET; Schema: public; Owner: insertion
--

SELECT pg_catalog.setval('public.user_address_id_seq', 1, false);


--
-- Name: user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: insertion
--

SELECT pg_catalog.setval('public.user_id_seq', 1, false);


--
-- Name: user_notification_id_seq; Type: SEQUENCE SET; Schema: public; Owner: insertion
--

SELECT pg_catalog.setval('public.user_notification_id_seq', 1, false);


--
-- Name: access_token PK_ACCESS_TOKEN; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.access_token
    ADD CONSTRAINT "PK_ACCESS_TOKEN" PRIMARY KEY (id);


--
-- Name: address PK_ADDRESS; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.address
    ADD CONSTRAINT "PK_ADDRESS" PRIMARY KEY (id);


--
-- Name: agenda_event PK_AGENDA_EVENT_ID; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.agenda_event
    ADD CONSTRAINT "PK_AGENDA_EVENT_ID" PRIMARY KEY (id);


--
-- Name: asset PK_ASSET; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.asset
    ADD CONSTRAINT "PK_ASSET" PRIMARY KEY (id);


--
-- Name: barrier PK_BARRIER; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.barrier
    ADD CONSTRAINT "PK_BARRIER" PRIMARY KEY (id);


--
-- Name: beneficiary_address PK_BENEFICIARY_ADDRESS_ID; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.beneficiary_address
    ADD CONSTRAINT "PK_BENEFICIARY_ADDRESS_ID" PRIMARY KEY (id);


--
-- Name: beneficiary_complement PK_BENEFICIARY_COMPLEMENT_ID; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.beneficiary_complement
    ADD CONSTRAINT "PK_BENEFICIARY_COMPLEMENT_ID" PRIMARY KEY (id);


--
-- Name: beneficiary_employment PK_BENEFICIARY_EMPLOYMENT_ID; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.beneficiary_employment
    ADD CONSTRAINT "PK_BENEFICIARY_EMPLOYMENT_ID" PRIMARY KEY (id);


--
-- Name: beneficiary_employment_jobs_job PK_BENEFICIARY_EMPLOYMENT_JOBS_JOB; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.beneficiary_employment_jobs_job
    ADD CONSTRAINT "PK_BENEFICIARY_EMPLOYMENT_JOBS_JOB" PRIMARY KEY ("beneficiaryEmploymentId", "jobId");


--
-- Name: beneficiary PK_BENEFICIARY_ID; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.beneficiary
    ADD CONSTRAINT "PK_BENEFICIARY_ID" PRIMARY KEY (id);


--
-- Name: beneficiary_postal_history PK_BENEFICIARY_POSTAL_HISTORY; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.beneficiary_postal_history
    ADD CONSTRAINT "PK_BENEFICIARY_POSTAL_HISTORY" PRIMARY KEY ("beneficiaryId", "beneficiaryAddressId");


--
-- Name: beneficiary_residential_history PK_BENEFICIARY_RESIDENTIAL_HISTORY; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.beneficiary_residential_history
    ADD CONSTRAINT "PK_BENEFICIARY_RESIDENTIAL_HISTORY" PRIMARY KEY ("beneficiaryId", "beneficiaryAddressId");


--
-- Name: beneficiary_rsj PK_BENEFICIARY_RSJ; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.beneficiary_rsj
    ADD CONSTRAINT "PK_BENEFICIARY_RSJ" PRIMARY KEY (id);


--
-- Name: beneficiary_rsj_referent_history PK_BENEFICIARY_RSJ_HISTORY; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.beneficiary_rsj_referent_history
    ADD CONSTRAINT "PK_BENEFICIARY_RSJ_HISTORY" PRIMARY KEY ("beneficiaryRsjId", "referentId");


--
-- Name: beneficiary_rsj_payment_data_history PK_BENEFICIARY_RSJ_PAYMENT_DATA_HISTORY; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.beneficiary_rsj_payment_data_history
    ADD CONSTRAINT "PK_BENEFICIARY_RSJ_PAYMENT_DATA_HISTORY" PRIMARY KEY ("beneficiaryRsjId", "rsjPaymentDataId");


--
-- Name: children PK_CHILDREN_ID; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.children
    ADD CONSTRAINT "PK_CHILDREN_ID" PRIMARY KEY (id);


--
-- Name: clearance PK_CLEARANCE; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.clearance
    ADD CONSTRAINT "PK_CLEARANCE" PRIMARY KEY (name);


--
-- Name: clearance_category PK_CLEARANCE_CATEGORY; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.clearance_category
    ADD CONSTRAINT "PK_CLEARANCE_CATEGORY" PRIMARY KEY (name);


--
-- Name: clearance_group PK_CLEARANCE_GROUP; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.clearance_group
    ADD CONSTRAINT "PK_CLEARANCE_GROUP" PRIMARY KEY ("clearanceName", "groupName");


--
-- Name: clearance_user PK_CLEARANCE_USER; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.clearance_user
    ADD CONSTRAINT "PK_CLEARANCE_USER" PRIMARY KEY ("clearanceName", "userId");


--
-- Name: cli PK_CLI; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.cli
    ADD CONSTRAINT "PK_CLI" PRIMARY KEY (id);


--
-- Name: community_action PK_COMMUNITY_ACTION; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.community_action
    ADD CONSTRAINT "PK_COMMUNITY_ACTION" PRIMARY KEY (id);


--
-- Name: contract PK_CONTRACT_ID; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.contract
    ADD CONSTRAINT "PK_CONTRACT_ID" PRIMARY KEY (id);


--
-- Name: contract_ier PK_CONTRACT_IER_ID; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.contract_ier
    ADD CONSTRAINT "PK_CONTRACT_IER_ID" PRIMARY KEY (id);


--
-- Name: course PK_COURSE; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.course
    ADD CONSTRAINT "PK_COURSE" PRIMARY KEY (id);


--
-- Name: ctm PK_CTM; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.ctm
    ADD CONSTRAINT "PK_CTM" PRIMARY KEY (id);


--
-- Name: custom_query PK_CUSTOM_QUERY; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.custom_query
    ADD CONSTRAINT "PK_CUSTOM_QUERY" PRIMARY KEY (id);


--
-- Name: dashboard_counter PK_DASHBOARD_COUNTER; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.dashboard_counter
    ADD CONSTRAINT "PK_DASHBOARD_COUNTER" PRIMARY KEY (id);


--
-- Name: degree PK_DEGREE_ID; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.degree
    ADD CONSTRAINT "PK_DEGREE_ID" PRIMARY KEY (id);


--
-- Name: diagnostic_barrier PK_DIAGNOSTIC_BARRIER; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.diagnostic_barrier
    ADD CONSTRAINT "PK_DIAGNOSTIC_BARRIER" PRIMARY KEY (id);


--
-- Name: diagnostic PK_DIAGNOSTIC_ID; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.diagnostic
    ADD CONSTRAINT "PK_DIAGNOSTIC_ID" PRIMARY KEY (id);


--
-- Name: diagnostic_qualification_type PK_DIAGNOSTIC_QUALIFICATION; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.diagnostic_qualification_type
    ADD CONSTRAINT "PK_DIAGNOSTIC_QUALIFICATION" PRIMARY KEY (id);


--
-- Name: document PK_DOCUMENT; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.document
    ADD CONSTRAINT "PK_DOCUMENT" PRIMARY KEY (id);


--
-- Name: document_status PK_DOCUMENT_STATUS_ID; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.document_status
    ADD CONSTRAINT "PK_DOCUMENT_STATUS_ID" PRIMARY KEY (id);


--
-- Name: document_title PK_DOCUMENT_TITLE; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.document_title
    ADD CONSTRAINT "PK_DOCUMENT_TITLE" PRIMARY KEY (id);


--
-- Name: domain PK_DOMAIN; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.domain
    ADD CONSTRAINT "PK_DOMAIN" PRIMARY KEY (id);


--
-- Name: employment_asset PK_EMPLOYMENT_ASSET; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.employment_asset
    ADD CONSTRAINT "PK_EMPLOYMENT_ASSET" PRIMARY KEY (id);


--
-- Name: employment_barrier PK_EMPLOYMENT_BARRIER_ID; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.employment_barrier
    ADD CONSTRAINT "PK_EMPLOYMENT_BARRIER_ID" PRIMARY KEY (id);


--
-- Name: employment_qualification_type PK_EMPLOYMENT_QUALICATION_TYPE_ID; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.employment_qualification_type
    ADD CONSTRAINT "PK_EMPLOYMENT_QUALICATION_TYPE_ID" PRIMARY KEY (id);


--
-- Name: employment_training_area PK_EMPLOYMENT_TRAINING_AREA; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.employment_training_area
    ADD CONSTRAINT "PK_EMPLOYMENT_TRAINING_AREA" PRIMARY KEY ("beneficiaryEmploymentId", "trainingAreaId");


--
-- Name: employment_transport_mode PK_EMPLOYMENT_TRANSPORT_MODE_ID; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.employment_transport_mode
    ADD CONSTRAINT "PK_EMPLOYMENT_TRANSPORT_MODE_ID" PRIMARY KEY (id);


--
-- Name: enrol PK_ENROL; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.enrol
    ADD CONSTRAINT "PK_ENROL" PRIMARY KEY (id);


--
-- Name: focus_area PK_FOCUS_AREA_ID; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.focus_area
    ADD CONSTRAINT "PK_FOCUS_AREA_ID" PRIMARY KEY (id);


--
-- Name: formation PK_FORMATION_ID; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.formation
    ADD CONSTRAINT "PK_FORMATION_ID" PRIMARY KEY (id);


--
-- Name: group PK_GROUP; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public."group"
    ADD CONSTRAINT "PK_GROUP" PRIMARY KEY (name);


--
-- Name: health_insurance PK_HEALTH_INSURANCE_ID; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.health_insurance
    ADD CONSTRAINT "PK_HEALTH_INSURANCE_ID" PRIMARY KEY (id);


--
-- Name: home PK_HOME; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.home
    ADD CONSTRAINT "PK_HOME" PRIMARY KEY (id);


--
-- Name: instruction_rsj PK_INSTRUCTION_RSJ_ID; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.instruction_rsj
    ADD CONSTRAINT "PK_INSTRUCTION_RSJ_ID" PRIMARY KEY (id);


--
-- Name: instruction_rsj_mobilized_plan PK_INSTRUCTION_RSJ_ID_MOBILIZED_PLAN_ID; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.instruction_rsj_mobilized_plan
    ADD CONSTRAINT "PK_INSTRUCTION_RSJ_ID_MOBILIZED_PLAN_ID" PRIMARY KEY ("instructionRsjId", "rsjMobilizedPlanId");


--
-- Name: instruction_rsj_situation PK_INSTRUCTION_RSJ_ID_SITUATION_ID; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.instruction_rsj_situation
    ADD CONSTRAINT "PK_INSTRUCTION_RSJ_ID_SITUATION_ID" PRIMARY KEY ("instructionRsjId", "rsjSituationId");


--
-- Name: instruction_rsj_income PK_INSTRUCTION_RSJ_INCOME_ID; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.instruction_rsj_income
    ADD CONSTRAINT "PK_INSTRUCTION_RSJ_INCOME_ID" PRIMARY KEY (id);


--
-- Name: instruction_rsj_non_renewal PK_INS_RSJ_NON_RENEWAL; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.instruction_rsj_non_renewal
    ADD CONSTRAINT "PK_INS_RSJ_NON_RENEWAL" PRIMARY KEY (id);


--
-- Name: instruction_rsj_other_document PK_INS_RSJ_OTHER_DOCUMENT; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.instruction_rsj_other_document
    ADD CONSTRAINT "PK_INS_RSJ_OTHER_DOCUMENT" PRIMARY KEY ("instructionRsjId", "documentId");


--
-- Name: instruction_rsj_use_title PK_INS_RSJ_USE_TITLE; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.instruction_rsj_use_title
    ADD CONSTRAINT "PK_INS_RSJ_USE_TITLE" PRIMARY KEY (id);


--
-- Name: interview PK_INTERVIEW_ID; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.interview
    ADD CONSTRAINT "PK_INTERVIEW_ID" PRIMARY KEY (id);


--
-- Name: interview_theme PK_INTERVIEW_THEME_ID; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.interview_theme
    ADD CONSTRAINT "PK_INTERVIEW_THEME_ID" PRIMARY KEY (id);


--
-- Name: job PK_JOB_ID; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.job
    ADD CONSTRAINT "PK_JOB_ID" PRIMARY KEY (id);


--
-- Name: job_type PK_JOB_TYPE; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.job_type
    ADD CONSTRAINT "PK_JOB_TYPE" PRIMARY KEY (id);


--
-- Name: log PK_LOG; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.log
    ADD CONSTRAINT "PK_LOG" PRIMARY KEY (id);


--
-- Name: logo PK_LOGO; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.logo
    ADD CONSTRAINT "PK_LOGO" PRIMARY KEY (id);


--
-- Name: metropole_town PK_METROPOLE_TOWN; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.metropole_town
    ADD CONSTRAINT "PK_METROPOLE_TOWN" PRIMARY KEY ("codeInsee");


--
-- Name: orientation_history PK_ORIENTATION_HISTORY_ID; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.orientation_history
    ADD CONSTRAINT "PK_ORIENTATION_HISTORY_ID" PRIMARY KEY (id);


--
-- Name: qpv PK_QPV_ID; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.qpv
    ADD CONSTRAINT "PK_QPV_ID" PRIMARY KEY (id);


--
-- Name: qualification_type PK_QUALIFICATION_TYPE_ID; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.qualification_type
    ADD CONSTRAINT "PK_QUALIFICATION_TYPE_ID" PRIMARY KEY (id);


--
-- Name: referent PK_REFERENT; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.referent
    ADD CONSTRAINT "PK_REFERENT" PRIMARY KEY (id);


--
-- Name: referent_history PK_REFERENT_HISTORY; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.referent_history
    ADD CONSTRAINT "PK_REFERENT_HISTORY" PRIMARY KEY (id);


--
-- Name: refresh_token PK_REFRESH_TOKEN; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.refresh_token
    ADD CONSTRAINT "PK_REFRESH_TOKEN" PRIMARY KEY (id);


--
-- Name: rsj_mobilized_plan PK_RSJ_MOBILIZED_PLAN_ID; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.rsj_mobilized_plan
    ADD CONSTRAINT "PK_RSJ_MOBILIZED_PLAN_ID" PRIMARY KEY (id);


--
-- Name: rsj_payment PK_RSJ_PAYMENT; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.rsj_payment
    ADD CONSTRAINT "PK_RSJ_PAYMENT" PRIMARY KEY (id);


--
-- Name: rsj_payment_data PK_RSJ_PAYMENT_DATA; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.rsj_payment_data
    ADD CONSTRAINT "PK_RSJ_PAYMENT_DATA" PRIMARY KEY (id);


--
-- Name: rsj_payment_state PK_RSJ_PAYMENT_STATE; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.rsj_payment_state
    ADD CONSTRAINT "PK_RSJ_PAYMENT_STATE" PRIMARY KEY (id);


--
-- Name: rsj_reason PK_RSJ_REASON; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.rsj_reason
    ADD CONSTRAINT "PK_RSJ_REASON" PRIMARY KEY (id);


--
-- Name: rsj_situation PK_RSJ_SITUATION_ID; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.rsj_situation
    ADD CONSTRAINT "PK_RSJ_SITUATION_ID" PRIMARY KEY (id);


--
-- Name: rsj_state PK_RSJ_STATE; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.rsj_state
    ADD CONSTRAINT "PK_RSJ_STATE" PRIMARY KEY (id);


--
-- Name: sector PK_SECTOR_ID; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.sector
    ADD CONSTRAINT "PK_SECTOR_ID" PRIMARY KEY (id);


--
-- Name: session PK_SESSION; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT "PK_SESSION" PRIMARY KEY (id);


--
-- Name: signature PK_SIGNATURE; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.signature
    ADD CONSTRAINT "PK_SIGNATURE" PRIMARY KEY (id);


--
-- Name: stage PK_STAGE_ID; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.stage
    ADD CONSTRAINT "PK_STAGE_ID" PRIMARY KEY (id);


--
-- Name: stage_nature_type PK_STAGE_NATURE_TYPE_ID; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.stage_nature_type
    ADD CONSTRAINT "PK_STAGE_NATURE_TYPE_ID" PRIMARY KEY (id);


--
-- Name: structure_focus_area PK_STRUCTURE_FOCUS_AREA; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.structure_focus_area
    ADD CONSTRAINT "PK_STRUCTURE_FOCUS_AREA" PRIMARY KEY ("structureId", "focusAreaId");


--
-- Name: structure PK_STRUCTURE_ID; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.structure
    ADD CONSTRAINT "PK_STRUCTURE_ID" PRIMARY KEY (id);


--
-- Name: structure_to_area PK_STRUCTURE_TO_AREA; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.structure_to_area
    ADD CONSTRAINT "PK_STRUCTURE_TO_AREA" PRIMARY KEY ("cliId", "structureId", "supportTypeId");


--
-- Name: support_history PK_SUPPORT_HISTORY_ID; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.support_history
    ADD CONSTRAINT "PK_SUPPORT_HISTORY_ID" PRIMARY KEY (id);


--
-- Name: support_type PK_SUPPORT_TYPE_ID; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.support_type
    ADD CONSTRAINT "PK_SUPPORT_TYPE_ID" PRIMARY KEY (id);


--
-- Name: survey_fse PK_SURVEY_FSE; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.survey_fse
    ADD CONSTRAINT "PK_SURVEY_FSE" PRIMARY KEY (id);


--
-- Name: town PK_TOWN; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.town
    ADD CONSTRAINT "PK_TOWN" PRIMARY KEY ("codeInsee");


--
-- Name: traceability PK_TRACEABILITY_ID; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.traceability
    ADD CONSTRAINT "PK_TRACEABILITY_ID" PRIMARY KEY (id);


--
-- Name: training_area PK_TRAINING_AREA_ID; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.training_area
    ADD CONSTRAINT "PK_TRAINING_AREA_ID" PRIMARY KEY (id);


--
-- Name: transport_mode PK_TRANSPORT_MODE_ID; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.transport_mode
    ADD CONSTRAINT "PK_TRANSPORT_MODE_ID" PRIMARY KEY (id);


--
-- Name: user PK_USER; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT "PK_USER" PRIMARY KEY (id);


--
-- Name: user_address PK_USER_ADRESS; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.user_address
    ADD CONSTRAINT "PK_USER_ADRESS" PRIMARY KEY (id);


--
-- Name: user_ctm PK_USER_CTM; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.user_ctm
    ADD CONSTRAINT "PK_USER_CTM" PRIMARY KEY ("userId", "ctmId");


--
-- Name: user_group PK_USER_GROUP; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.user_group
    ADD CONSTRAINT "PK_USER_GROUP" PRIMARY KEY ("userId", "groupName");


--
-- Name: user_notification PK_USER_NOTIFICATION; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.user_notification
    ADD CONSTRAINT "PK_USER_NOTIFICATION" PRIMARY KEY (id);


--
-- Name: agenda_event REL_AGENDA_EVENT_INTERVIEW; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.agenda_event
    ADD CONSTRAINT "REL_AGENDA_EVENT_INTERVIEW" UNIQUE ("interviewId");


--
-- Name: beneficiary REL_BENEFICIARY_COMPLEMENT; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.beneficiary
    ADD CONSTRAINT "REL_BENEFICIARY_COMPLEMENT" UNIQUE ("beneficiaryComplementId");


--
-- Name: beneficiary REL_BENEFICIARY_EMPLOYMENT; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.beneficiary
    ADD CONSTRAINT "REL_BENEFICIARY_EMPLOYMENT" UNIQUE ("beneficiaryEmploymentId");


--
-- Name: document_status REL_DOCUMENT_STATUS_DOCUMENT; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.document_status
    ADD CONSTRAINT "REL_DOCUMENT_STATUS_DOCUMENT" UNIQUE ("documentId");


--
-- Name: user UK_USER_EMAIL; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT "UK_USER_EMAIL" UNIQUE (email);


--
-- Name: agenda_event UQ_AGENDA_EVENT_COURSE; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.agenda_event
    ADD CONSTRAINT "UQ_AGENDA_EVENT_COURSE" UNIQUE ("courseId");


--
-- Name: beneficiary_rsj UQ_BENEFICIARY_RSJ_BENEFICIARY; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.beneficiary_rsj
    ADD CONSTRAINT "UQ_BENEFICIARY_RSJ_BENEFICIARY" UNIQUE ("beneficiaryId");


--
-- Name: course UQ_COURSE_AGENDA_EVENT; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.course
    ADD CONSTRAINT "UQ_COURSE_AGENDA_EVENT" UNIQUE ("eventId");


--
-- Name: custom_query UQ_CUSTOM_QUERY; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.custom_query
    ADD CONSTRAINT "UQ_CUSTOM_QUERY" UNIQUE (name, "userId");


--
-- Name: enrol UQ_ENROL_STAGE; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.enrol
    ADD CONSTRAINT "UQ_ENROL_STAGE" UNIQUE ("stageId");


--
-- Name: signature UQ_SIGNATURE_CONTRACT; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.signature
    ADD CONSTRAINT "UQ_SIGNATURE_CONTRACT" UNIQUE ("contractId");


--
-- Name: signature UQ_SIGNATURE_CONTRACT_IER; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.signature
    ADD CONSTRAINT "UQ_SIGNATURE_CONTRACT_IER" UNIQUE ("contractIerId");


--
-- Name: signature UQ_SIGNATURE_INSTRUCTION_RSJ; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.signature
    ADD CONSTRAINT "UQ_SIGNATURE_INSTRUCTION_RSJ" UNIQUE ("instructionRsjId");


--
-- Name: signature UQ_SIGNATURE_USER; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.signature
    ADD CONSTRAINT "UQ_SIGNATURE_USER" UNIQUE ("userId");


--
-- Name: stage UQ_STAGE_ENROL; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.stage
    ADD CONSTRAINT "UQ_STAGE_ENROL" UNIQUE ("enrolId");


--
-- Name: structure UQ_STRUCTURE_IDIODAS; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.structure
    ADD CONSTRAINT "UQ_STRUCTURE_IDIODAS" UNIQUE ("idIODAS");


--
-- Name: structure UQ_STRUCTURE_LABEL; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.structure
    ADD CONSTRAINT "UQ_STRUCTURE_LABEL" UNIQUE (label);


--
-- Name: structure UQ_STRUCTURE_LOGO; Type: CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.structure
    ADD CONSTRAINT "UQ_STRUCTURE_LOGO" UNIQUE ("logoId");


--
-- Name: IDX_BENEFICIARY_EMPLOYMENT; Type: INDEX; Schema: public; Owner: insertion
--

CREATE INDEX "IDX_BENEFICIARY_EMPLOYMENT" ON public.beneficiary_employment_jobs_job USING btree ("beneficiaryEmploymentId");


--
-- Name: IDX_BENEFICIARY_POS_HISTORY_ADD; Type: INDEX; Schema: public; Owner: insertion
--

CREATE INDEX "IDX_BENEFICIARY_POS_HISTORY_ADD" ON public.beneficiary_postal_history USING btree ("beneficiaryAddressId");


--
-- Name: IDX_BENEFICIARY_POS_HISTORY_BEN; Type: INDEX; Schema: public; Owner: insertion
--

CREATE INDEX "IDX_BENEFICIARY_POS_HISTORY_BEN" ON public.beneficiary_postal_history USING btree ("beneficiaryId");


--
-- Name: IDX_BENEFICIARY_RES_HISTORY_ADD; Type: INDEX; Schema: public; Owner: insertion
--

CREATE INDEX "IDX_BENEFICIARY_RES_HISTORY_ADD" ON public.beneficiary_residential_history USING btree ("beneficiaryAddressId");


--
-- Name: IDX_BENEFICIARY_RES_HISTORY_BEN; Type: INDEX; Schema: public; Owner: insertion
--

CREATE INDEX "IDX_BENEFICIARY_RES_HISTORY_BEN" ON public.beneficiary_residential_history USING btree ("beneficiaryId");


--
-- Name: IDX_CLI_LABEL; Type: INDEX; Schema: public; Owner: insertion
--

CREATE UNIQUE INDEX "IDX_CLI_LABEL" ON public.cli USING btree (label);


--
-- Name: IDX_CLR_GROUP_CLEARANCE; Type: INDEX; Schema: public; Owner: insertion
--

CREATE INDEX "IDX_CLR_GROUP_CLEARANCE" ON public.clearance_group USING btree ("clearanceName");


--
-- Name: IDX_CLR_GROUP_GROUP; Type: INDEX; Schema: public; Owner: insertion
--

CREATE INDEX "IDX_CLR_GROUP_GROUP" ON public.clearance_group USING btree ("groupName");


--
-- Name: IDX_CLR_USER_CLEARANCE; Type: INDEX; Schema: public; Owner: insertion
--

CREATE INDEX "IDX_CLR_USER_CLEARANCE" ON public.clearance_user USING btree ("clearanceName");


--
-- Name: IDX_CLR_USER_USER; Type: INDEX; Schema: public; Owner: insertion
--

CREATE INDEX "IDX_CLR_USER_USER" ON public.clearance_user USING btree ("userId");


--
-- Name: IDX_CTM_LABEL; Type: INDEX; Schema: public; Owner: insertion
--

CREATE UNIQUE INDEX "IDX_CTM_LABEL" ON public.ctm USING btree (label);


--
-- Name: IDX_ETA_BENEFICIARY_EMPLOYMENT_ID; Type: INDEX; Schema: public; Owner: insertion
--

CREATE INDEX "IDX_ETA_BENEFICIARY_EMPLOYMENT_ID" ON public.employment_training_area USING btree ("beneficiaryEmploymentId");


--
-- Name: IDX_ETA_TRAINING_AREA_ID; Type: INDEX; Schema: public; Owner: insertion
--

CREATE INDEX "IDX_ETA_TRAINING_AREA_ID" ON public.employment_training_area USING btree ("trainingAreaId");


--
-- Name: IDX_INSERTIS_ID; Type: INDEX; Schema: public; Owner: insertion
--

CREATE UNIQUE INDEX "IDX_INSERTIS_ID" ON public.beneficiary USING btree ("insertisId");


--
-- Name: IDX_INSTRUCTION_RSJ_MOBILIZED_PLAN_INS; Type: INDEX; Schema: public; Owner: insertion
--

CREATE INDEX "IDX_INSTRUCTION_RSJ_MOBILIZED_PLAN_INS" ON public.instruction_rsj_mobilized_plan USING btree ("instructionRsjId");


--
-- Name: IDX_INSTRUCTION_RSJ_MOBILIZED_PLAN_MOB_PLA; Type: INDEX; Schema: public; Owner: insertion
--

CREATE INDEX "IDX_INSTRUCTION_RSJ_MOBILIZED_PLAN_MOB_PLA" ON public.instruction_rsj_mobilized_plan USING btree ("rsjMobilizedPlanId");


--
-- Name: IDX_INSTRUCTION_RSJ_SITUATION_INS; Type: INDEX; Schema: public; Owner: insertion
--

CREATE INDEX "IDX_INSTRUCTION_RSJ_SITUATION_INS" ON public.instruction_rsj_situation USING btree ("instructionRsjId");


--
-- Name: IDX_INSTRUCTION_RSJ_SITUATION_SIT; Type: INDEX; Schema: public; Owner: insertion
--

CREATE INDEX "IDX_INSTRUCTION_RSJ_SITUATION_SIT" ON public.instruction_rsj_situation USING btree ("rsjSituationId");


--
-- Name: IDX_JOB; Type: INDEX; Schema: public; Owner: insertion
--

CREATE INDEX "IDX_JOB" ON public.beneficiary_employment_jobs_job USING btree ("jobId");


--
-- Name: IDX_STRUCTURE_FOCUS_AREA_AREA_ID; Type: INDEX; Schema: public; Owner: insertion
--

CREATE INDEX "IDX_STRUCTURE_FOCUS_AREA_AREA_ID" ON public.structure_focus_area USING btree ("focusAreaId");


--
-- Name: IDX_STRUCTURE_FOCUS_AREA_STRU_ID; Type: INDEX; Schema: public; Owner: insertion
--

CREATE INDEX "IDX_STRUCTURE_FOCUS_AREA_STRU_ID" ON public.structure_focus_area USING btree ("structureId");


--
-- Name: IDX_USER_CTM_CTMID; Type: INDEX; Schema: public; Owner: insertion
--

CREATE INDEX "IDX_USER_CTM_CTMID" ON public.user_ctm USING btree ("ctmId");


--
-- Name: IDX_USER_CTM_USER; Type: INDEX; Schema: public; Owner: insertion
--

CREATE INDEX "IDX_USER_CTM_USER" ON public.user_ctm USING btree ("userId");


--
-- Name: IDX_USER_GROUP_GROUPNAME; Type: INDEX; Schema: public; Owner: insertion
--

CREATE INDEX "IDX_USER_GROUP_GROUPNAME" ON public.user_group USING btree ("groupName");


--
-- Name: IDX_USER_GROUP_USER; Type: INDEX; Schema: public; Owner: insertion
--

CREATE INDEX "IDX_USER_GROUP_USER" ON public.user_group USING btree ("userId");


--
-- Name: beneficiary_unaccent_firstname_idx; Type: INDEX; Schema: public; Owner: insertion
--

CREATE INDEX beneficiary_unaccent_firstname_idx ON public.beneficiary USING btree (public.f_unaccent(("firstName")::text));


--
-- Name: beneficiary_unaccent_usualname_idx; Type: INDEX; Schema: public; Owner: insertion
--

CREATE INDEX beneficiary_unaccent_usualname_idx ON public.beneficiary USING btree (public.f_unaccent(("usualName")::text));


--
-- Name: employment_training_area employment_training_area_stamp; Type: TRIGGER; Schema: public; Owner: insertion
--

CREATE TRIGGER employment_training_area_stamp BEFORE INSERT OR UPDATE ON public.employment_training_area FOR EACH ROW EXECUTE FUNCTION public.employment_training_area_stamp();


--
-- Name: access_token FK_ACCESS_TOKEN_USER; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.access_token
    ADD CONSTRAINT "FK_ACCESS_TOKEN_USER" FOREIGN KEY ("userId") REFERENCES public."user"(id);


--
-- Name: agenda_event FK_AGENDA_EVENT_COURSE; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.agenda_event
    ADD CONSTRAINT "FK_AGENDA_EVENT_COURSE" FOREIGN KEY ("courseId") REFERENCES public.course(id) ON DELETE CASCADE;


--
-- Name: agenda_event FK_AGENDA_EVENT_INTERVIEW; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.agenda_event
    ADD CONSTRAINT "FK_AGENDA_EVENT_INTERVIEW" FOREIGN KEY ("interviewId") REFERENCES public.interview(id) ON DELETE CASCADE;


--
-- Name: agenda_event FK_AGENDA_EVENT_SUPPORT_TYPE; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.agenda_event
    ADD CONSTRAINT "FK_AGENDA_EVENT_SUPPORT_TYPE" FOREIGN KEY ("supportTypeId") REFERENCES public.support_type(id);


--
-- Name: agenda_event FK_AGENDA_EVENT_USER; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.agenda_event
    ADD CONSTRAINT "FK_AGENDA_EVENT_USER" FOREIGN KEY ("userId") REFERENCES public."user"(id);


--
-- Name: beneficiary_address FK_BENEFICIARY_ADDRESS_CLI; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.beneficiary_address
    ADD CONSTRAINT "FK_BENEFICIARY_ADDRESS_CLI" FOREIGN KEY ("cliId") REFERENCES public.cli(id);


--
-- Name: beneficiary_address FK_BENEFICIARY_ADDRESS_CTM; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.beneficiary_address
    ADD CONSTRAINT "FK_BENEFICIARY_ADDRESS_CTM" FOREIGN KEY ("ctmId") REFERENCES public.ctm(id);


--
-- Name: beneficiary_address FK_BENEFICIARY_ADDRESS_QPV; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.beneficiary_address
    ADD CONSTRAINT "FK_BENEFICIARY_ADDRESS_QPV" FOREIGN KEY ("qpvId") REFERENCES public.qpv(id);


--
-- Name: beneficiary FK_BENEFICIARY_BENEFICIARY_COMPLEMENT; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.beneficiary
    ADD CONSTRAINT "FK_BENEFICIARY_BENEFICIARY_COMPLEMENT" FOREIGN KEY ("beneficiaryComplementId") REFERENCES public.beneficiary_complement(id);


--
-- Name: beneficiary FK_BENEFICIARY_BENEFICIARY_EMPLOYMENT; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.beneficiary
    ADD CONSTRAINT "FK_BENEFICIARY_BENEFICIARY_EMPLOYMENT" FOREIGN KEY ("beneficiaryEmploymentId") REFERENCES public.beneficiary_employment(id);


--
-- Name: beneficiary_complement FK_BENEFICIARY_COMPLEMENT_HEALTH_INSURANCE; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.beneficiary_complement
    ADD CONSTRAINT "FK_BENEFICIARY_COMPLEMENT_HEALTH_INSURANCE" FOREIGN KEY ("healthInsuranceId") REFERENCES public.health_insurance(id);


--
-- Name: beneficiary_complement FK_BENEFICIARY_COMPLEMENT_USER; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.beneficiary_complement
    ADD CONSTRAINT "FK_BENEFICIARY_COMPLEMENT_USER" FOREIGN KEY ("referentId") REFERENCES public."user"(id);


--
-- Name: beneficiary_employment FK_BENEFICIARY_EMPLOYMENT_DEGREE; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.beneficiary_employment
    ADD CONSTRAINT "FK_BENEFICIARY_EMPLOYMENT_DEGREE" FOREIGN KEY ("degreeId") REFERENCES public.degree(id);


--
-- Name: beneficiary_employment_jobs_job FK_BENEFICIARY_EMPLOYMENT_JOBS_JOB_BEN_EMP; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.beneficiary_employment_jobs_job
    ADD CONSTRAINT "FK_BENEFICIARY_EMPLOYMENT_JOBS_JOB_BEN_EMP" FOREIGN KEY ("beneficiaryEmploymentId") REFERENCES public.beneficiary_employment(id) ON DELETE CASCADE;


--
-- Name: beneficiary_employment_jobs_job FK_BENEFICIARY_EMPLOYMENT_JOBS_JOB_JOB; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.beneficiary_employment_jobs_job
    ADD CONSTRAINT "FK_BENEFICIARY_EMPLOYMENT_JOBS_JOB_JOB" FOREIGN KEY ("jobId") REFERENCES public.job(id) ON DELETE CASCADE;


--
-- Name: beneficiary_employment FK_BENEFICIARY_EMPLOYMENT_SECTOR; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.beneficiary_employment
    ADD CONSTRAINT "FK_BENEFICIARY_EMPLOYMENT_SECTOR" FOREIGN KEY ("sectorId") REFERENCES public.sector(id);


--
-- Name: beneficiary FK_BENEFICIARY_POSTAL_ADDRESS; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.beneficiary
    ADD CONSTRAINT "FK_BENEFICIARY_POSTAL_ADDRESS" FOREIGN KEY ("postalAddressId") REFERENCES public.beneficiary_address(id);


--
-- Name: beneficiary_postal_history FK_BENEFICIARY_POS_HISTORY_ADD; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.beneficiary_postal_history
    ADD CONSTRAINT "FK_BENEFICIARY_POS_HISTORY_ADD" FOREIGN KEY ("beneficiaryAddressId") REFERENCES public.beneficiary_address(id) ON DELETE CASCADE;


--
-- Name: beneficiary_postal_history FK_BENEFICIARY_POS_HISTORY_BEN; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.beneficiary_postal_history
    ADD CONSTRAINT "FK_BENEFICIARY_POS_HISTORY_BEN" FOREIGN KEY ("beneficiaryId") REFERENCES public.beneficiary(id) ON DELETE CASCADE;


--
-- Name: beneficiary FK_BENEFICIARY_RESIDENTIAL_ADDRESS; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.beneficiary
    ADD CONSTRAINT "FK_BENEFICIARY_RESIDENTIAL_ADDRESS" FOREIGN KEY ("residentialAddressId") REFERENCES public.beneficiary_address(id);


--
-- Name: beneficiary_residential_history FK_BENEFICIARY_RES_HISTORY_ADD; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.beneficiary_residential_history
    ADD CONSTRAINT "FK_BENEFICIARY_RES_HISTORY_ADD" FOREIGN KEY ("beneficiaryAddressId") REFERENCES public.beneficiary_address(id) ON DELETE CASCADE;


--
-- Name: beneficiary_residential_history FK_BENEFICIARY_RES_HISTORY_BEN; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.beneficiary_residential_history
    ADD CONSTRAINT "FK_BENEFICIARY_RES_HISTORY_BEN" FOREIGN KEY ("beneficiaryId") REFERENCES public.beneficiary(id) ON DELETE CASCADE;


--
-- Name: beneficiary_rsj FK_BENEFICIARY_RSJ_BENEFICIARY; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.beneficiary_rsj
    ADD CONSTRAINT "FK_BENEFICIARY_RSJ_BENEFICIARY" FOREIGN KEY ("beneficiaryId") REFERENCES public.beneficiary(id);


--
-- Name: beneficiary_rsj FK_BENEFICIARY_RSJ_PAYMENT_DATA; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.beneficiary_rsj
    ADD CONSTRAINT "FK_BENEFICIARY_RSJ_PAYMENT_DATA" FOREIGN KEY ("paymentDataId") REFERENCES public.rsj_payment_data(id);


--
-- Name: beneficiary_rsj FK_BENEFICIARY_RSJ_REASON; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.beneficiary_rsj
    ADD CONSTRAINT "FK_BENEFICIARY_RSJ_REASON" FOREIGN KEY ("reasonId") REFERENCES public.rsj_reason(id);


--
-- Name: beneficiary_rsj FK_BENEFICIARY_RSJ_REFERENT; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.beneficiary_rsj
    ADD CONSTRAINT "FK_BENEFICIARY_RSJ_REFERENT" FOREIGN KEY ("referentId") REFERENCES public.referent(id);


--
-- Name: beneficiary_rsj FK_BENEFICIARY_RSJ_STATE; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.beneficiary_rsj
    ADD CONSTRAINT "FK_BENEFICIARY_RSJ_STATE" FOREIGN KEY ("stateId") REFERENCES public.rsj_state(id);


--
-- Name: beneficiary FK_BENEFICIARY_STRUCTURE; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.beneficiary
    ADD CONSTRAINT "FK_BENEFICIARY_STRUCTURE" FOREIGN KEY ("structureId") REFERENCES public.structure(id);


--
-- Name: beneficiary FK_BENEFICIARY_SUPPORT_TYPE; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.beneficiary
    ADD CONSTRAINT "FK_BENEFICIARY_SUPPORT_TYPE" FOREIGN KEY ("supportTypeId") REFERENCES public.support_type(id);


--
-- Name: beneficiary_employment FK_BE_WANTED_JOB_TYPE_ID; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.beneficiary_employment
    ADD CONSTRAINT "FK_BE_WANTED_JOB_TYPE_ID" FOREIGN KEY ("wantedJobTypeId") REFERENCES public.job_type(id);


--
-- Name: children FK_CHILDREN_DIAGNOSTIC; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.children
    ADD CONSTRAINT "FK_CHILDREN_DIAGNOSTIC" FOREIGN KEY ("diagnosticId") REFERENCES public.diagnostic(id) ON DELETE CASCADE;


--
-- Name: clearance FK_CLEARANCE_CATEGORY; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.clearance
    ADD CONSTRAINT "FK_CLEARANCE_CATEGORY" FOREIGN KEY ("categoryName") REFERENCES public.clearance_category(name);


--
-- Name: clearance_group FK_CLR_GROUP_CLEARANCE; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.clearance_group
    ADD CONSTRAINT "FK_CLR_GROUP_CLEARANCE" FOREIGN KEY ("clearanceName") REFERENCES public.clearance(name) ON DELETE CASCADE;


--
-- Name: clearance_group FK_CLR_GROUP_GROUP; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.clearance_group
    ADD CONSTRAINT "FK_CLR_GROUP_GROUP" FOREIGN KEY ("groupName") REFERENCES public."group"(name) ON DELETE CASCADE;


--
-- Name: clearance_user FK_CLR_USER_CLEARANCE; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.clearance_user
    ADD CONSTRAINT "FK_CLR_USER_CLEARANCE" FOREIGN KEY ("clearanceName") REFERENCES public.clearance(name) ON DELETE CASCADE;


--
-- Name: clearance_user FK_CLR_USER_USER; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.clearance_user
    ADD CONSTRAINT "FK_CLR_USER_USER" FOREIGN KEY ("userId") REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: session FK_COMMUNITY_ACTION_SESSION; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT "FK_COMMUNITY_ACTION_SESSION" FOREIGN KEY ("communityActionId") REFERENCES public.community_action(id);


--
-- Name: community_action FK_COMMUNTY_ACTION_CLI; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.community_action
    ADD CONSTRAINT "FK_COMMUNTY_ACTION_CLI" FOREIGN KEY ("cliId") REFERENCES public.cli(id);


--
-- Name: community_action FK_COMMUNTY_ACTION_CTM; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.community_action
    ADD CONSTRAINT "FK_COMMUNTY_ACTION_CTM" FOREIGN KEY ("ctmId") REFERENCES public.ctm(id);


--
-- Name: community_action FK_COMMUNTY_ACTION_STAGE_NATURE_TYPE; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.community_action
    ADD CONSTRAINT "FK_COMMUNTY_ACTION_STAGE_NATURE_TYPE" FOREIGN KEY ("stageNatureTypeId") REFERENCES public.stage_nature_type(id);


--
-- Name: community_action FK_COMMUNTY_ACTION_STRUCTURE; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.community_action
    ADD CONSTRAINT "FK_COMMUNTY_ACTION_STRUCTURE" FOREIGN KEY ("structureId") REFERENCES public.structure(id);


--
-- Name: contract FK_CONTRACT_BENEFICIARY; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.contract
    ADD CONSTRAINT "FK_CONTRACT_BENEFICIARY" FOREIGN KEY ("beneficiaryId") REFERENCES public.beneficiary(id) ON DELETE CASCADE;


--
-- Name: contract_ier FK_CONTRACT_IER_BENEFICIARY; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.contract_ier
    ADD CONSTRAINT "FK_CONTRACT_IER_BENEFICIARY" FOREIGN KEY ("beneficiaryId") REFERENCES public.beneficiary(id) ON DELETE CASCADE;


--
-- Name: contract_ier FK_CONTRACT_IER_STRUCTURE; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.contract_ier
    ADD CONSTRAINT "FK_CONTRACT_IER_STRUCTURE" FOREIGN KEY ("structureId") REFERENCES public.structure(id);


--
-- Name: contract_ier FK_CONTRACT_IER_SUPPORT_TYPE; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.contract_ier
    ADD CONSTRAINT "FK_CONTRACT_IER_SUPPORT_TYPE" FOREIGN KEY ("supportTypeId") REFERENCES public.support_type(id);


--
-- Name: contract_ier FK_CONTRACT_IER_USER; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.contract_ier
    ADD CONSTRAINT "FK_CONTRACT_IER_USER" FOREIGN KEY ("referentId") REFERENCES public."user"(id);


--
-- Name: contract_ier FK_CONTRACT_IER_USER_DIRECTION; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.contract_ier
    ADD CONSTRAINT "FK_CONTRACT_IER_USER_DIRECTION" FOREIGN KEY ("directionSignatoryId") REFERENCES public."user"(id);


--
-- Name: contract_ier FK_CONTRACT_IER_USER_STRUCTURE; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.contract_ier
    ADD CONSTRAINT "FK_CONTRACT_IER_USER_STRUCTURE" FOREIGN KEY ("structureSignatoryId") REFERENCES public."user"(id);


--
-- Name: contract FK_CONTRACT_STRUCTURE; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.contract
    ADD CONSTRAINT "FK_CONTRACT_STRUCTURE" FOREIGN KEY ("structureId") REFERENCES public.structure(id);


--
-- Name: contract FK_CONTRACT_SUPPORT_TYPE; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.contract
    ADD CONSTRAINT "FK_CONTRACT_SUPPORT_TYPE" FOREIGN KEY ("supportTypeId") REFERENCES public.support_type(id);


--
-- Name: contract FK_CONTRACT_USER; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.contract
    ADD CONSTRAINT "FK_CONTRACT_USER" FOREIGN KEY ("referentId") REFERENCES public."user"(id);


--
-- Name: contract FK_CONTRACT_USER_DIRECTION; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.contract
    ADD CONSTRAINT "FK_CONTRACT_USER_DIRECTION" FOREIGN KEY ("directionSignatoryId") REFERENCES public."user"(id);


--
-- Name: contract FK_CONTRACT_USER_STRUCTURE; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.contract
    ADD CONSTRAINT "FK_CONTRACT_USER_STRUCTURE" FOREIGN KEY ("structureSignatoryId") REFERENCES public."user"(id);


--
-- Name: course FK_COURSE_AGENDA_EVENT; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.course
    ADD CONSTRAINT "FK_COURSE_AGENDA_EVENT" FOREIGN KEY ("eventId") REFERENCES public.agenda_event(id);


--
-- Name: custom_query FK_CUSTOM_QUERY_USER; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.custom_query
    ADD CONSTRAINT "FK_CUSTOM_QUERY_USER" FOREIGN KEY ("userId") REFERENCES public."user"(id);


--
-- Name: diagnostic_barrier FK_DIAGNOSTIC_BARRIER_BARRIER; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.diagnostic_barrier
    ADD CONSTRAINT "FK_DIAGNOSTIC_BARRIER_BARRIER" FOREIGN KEY ("barrierId") REFERENCES public.barrier(id);


--
-- Name: diagnostic_barrier FK_DIAGNOSTIC_BARRIER_DIAGNOSTIC; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.diagnostic_barrier
    ADD CONSTRAINT "FK_DIAGNOSTIC_BARRIER_DIAGNOSTIC" FOREIGN KEY ("diagnosticId") REFERENCES public.diagnostic(id) ON DELETE CASCADE;


--
-- Name: diagnostic FK_DIAGNOSTIC_BENEFICIARY; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.diagnostic
    ADD CONSTRAINT "FK_DIAGNOSTIC_BENEFICIARY" FOREIGN KEY ("beneficiaryId") REFERENCES public.beneficiary(id);


--
-- Name: diagnostic FK_DIAGNOSTIC_DEGREE; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.diagnostic
    ADD CONSTRAINT "FK_DIAGNOSTIC_DEGREE" FOREIGN KEY ("degreeId") REFERENCES public.degree(id);


--
-- Name: diagnostic_qualification_type FK_DIAGNOSTIC_QUALIFICATION_DIAGNOSTIC; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.diagnostic_qualification_type
    ADD CONSTRAINT "FK_DIAGNOSTIC_QUALIFICATION_DIAGNOSTIC" FOREIGN KEY ("diagnosticId") REFERENCES public.diagnostic(id) ON DELETE CASCADE;


--
-- Name: diagnostic FK_DIAGNOSTIC_STRUCTURE; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.diagnostic
    ADD CONSTRAINT "FK_DIAGNOSTIC_STRUCTURE" FOREIGN KEY ("structureId") REFERENCES public.structure(id);


--
-- Name: diagnostic FK_DIAGNOSTIC_USER; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.diagnostic
    ADD CONSTRAINT "FK_DIAGNOSTIC_USER" FOREIGN KEY ("referentId") REFERENCES public."user"(id);


--
-- Name: document FK_DOCUMENT_BENEFICIARY; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.document
    ADD CONSTRAINT "FK_DOCUMENT_BENEFICIARY" FOREIGN KEY ("beneficiaryId") REFERENCES public.beneficiary(id) ON DELETE CASCADE;


--
-- Name: document FK_DOCUMENT_DOCUMENT_TITLE; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.document
    ADD CONSTRAINT "FK_DOCUMENT_DOCUMENT_TITLE" FOREIGN KEY ("titleId") REFERENCES public.document_title(id);


--
-- Name: document_status FK_DOCUMENT_STATUS_DOCUMENT; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.document_status
    ADD CONSTRAINT "FK_DOCUMENT_STATUS_DOCUMENT" FOREIGN KEY ("documentId") REFERENCES public.document(id) ON DELETE CASCADE;


--
-- Name: document FK_DOCUMENT_USER; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.document
    ADD CONSTRAINT "FK_DOCUMENT_USER" FOREIGN KEY ("importedById") REFERENCES public."user"(id);


--
-- Name: domain FK_DOMAIN_SECTOR; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.domain
    ADD CONSTRAINT "FK_DOMAIN_SECTOR" FOREIGN KEY ("sectorId") REFERENCES public.sector(id);


--
-- Name: employment_asset FK_EA_ASSET_ID; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.employment_asset
    ADD CONSTRAINT "FK_EA_ASSET_ID" FOREIGN KEY ("assetId") REFERENCES public.asset(id);


--
-- Name: employment_asset FK_EA_BENEFICIARY_EMPLOYMENT_ID; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.employment_asset
    ADD CONSTRAINT "FK_EA_BENEFICIARY_EMPLOYMENT_ID" FOREIGN KEY ("beneficiaryEmploymentId") REFERENCES public.beneficiary_employment(id) ON DELETE CASCADE;


--
-- Name: employment_barrier FK_EMPLOYMENT_BARRIER_BAR; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.employment_barrier
    ADD CONSTRAINT "FK_EMPLOYMENT_BARRIER_BAR" FOREIGN KEY ("barrierId") REFERENCES public.barrier(id);


--
-- Name: employment_barrier FK_EMPLOYMENT_BARRIER_BEN_EMP; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.employment_barrier
    ADD CONSTRAINT "FK_EMPLOYMENT_BARRIER_BEN_EMP" FOREIGN KEY ("beneficiaryEmploymentId") REFERENCES public.beneficiary_employment(id) ON DELETE CASCADE;


--
-- Name: employment_qualification_type FK_EMPLOYMENT_QUALIFICATION_TYPE_BEN_EMP; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.employment_qualification_type
    ADD CONSTRAINT "FK_EMPLOYMENT_QUALIFICATION_TYPE_BEN_EMP" FOREIGN KEY ("beneficiaryEmploymentId") REFERENCES public.beneficiary_employment(id) ON DELETE CASCADE;


--
-- Name: employment_qualification_type FK_EMPLOYMENT_QUALIFICATION_TYPE_QUAL; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.employment_qualification_type
    ADD CONSTRAINT "FK_EMPLOYMENT_QUALIFICATION_TYPE_QUAL" FOREIGN KEY ("qualificationTypeId") REFERENCES public.qualification_type(id);


--
-- Name: employment_transport_mode FK_EMPLOYMENT_TRANSPORT_MODE_BEN_EMP; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.employment_transport_mode
    ADD CONSTRAINT "FK_EMPLOYMENT_TRANSPORT_MODE_BEN_EMP" FOREIGN KEY ("beneficiaryEmploymentId") REFERENCES public.beneficiary_employment(id) ON DELETE CASCADE;


--
-- Name: employment_transport_mode FK_EMPLOYMENT_TRANSPORT_MODE_TRA_MOD; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.employment_transport_mode
    ADD CONSTRAINT "FK_EMPLOYMENT_TRANSPORT_MODE_TRA_MOD" FOREIGN KEY ("transportModeId") REFERENCES public.transport_mode(id) ON DELETE CASCADE;


--
-- Name: enrol FK_ENROL_BENEFICIARY; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.enrol
    ADD CONSTRAINT "FK_ENROL_BENEFICIARY" FOREIGN KEY ("beneficiaryId") REFERENCES public.beneficiary(id) ON DELETE CASCADE;


--
-- Name: enrol FK_ENROL_SESSION; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.enrol
    ADD CONSTRAINT "FK_ENROL_SESSION" FOREIGN KEY ("sessionId") REFERENCES public.session(id);


--
-- Name: enrol FK_ENROL_STAGE; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.enrol
    ADD CONSTRAINT "FK_ENROL_STAGE" FOREIGN KEY ("stageId") REFERENCES public.stage(id);


--
-- Name: employment_training_area FK_ETA_BENEFICIARY_EMPLOYMENT_ID; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.employment_training_area
    ADD CONSTRAINT "FK_ETA_BENEFICIARY_EMPLOYMENT_ID" FOREIGN KEY ("beneficiaryEmploymentId") REFERENCES public.beneficiary_employment(id) ON DELETE CASCADE;


--
-- Name: employment_training_area FK_ETA_TRAINING_AREA_ID; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.employment_training_area
    ADD CONSTRAINT "FK_ETA_TRAINING_AREA_ID" FOREIGN KEY ("trainingAreaId") REFERENCES public.training_area(id) ON DELETE CASCADE;


--
-- Name: formation FK_FORMATION_DIAGNOSTIC; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.formation
    ADD CONSTRAINT "FK_FORMATION_DIAGNOSTIC" FOREIGN KEY ("diagnosticId") REFERENCES public.diagnostic(id) ON DELETE CASCADE;


--
-- Name: instruction_rsj FK_INSTRUCTION_RSJ_BENEFICIARY; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.instruction_rsj
    ADD CONSTRAINT "FK_INSTRUCTION_RSJ_BENEFICIARY" FOREIGN KEY ("beneficiaryId") REFERENCES public.beneficiary(id) ON DELETE CASCADE;


--
-- Name: instruction_rsj FK_INSTRUCTION_RSJ_HEALTH_INSURANCE; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.instruction_rsj
    ADD CONSTRAINT "FK_INSTRUCTION_RSJ_HEALTH_INSURANCE" FOREIGN KEY ("healthInsuranceId") REFERENCES public.health_insurance(id);


--
-- Name: instruction_rsj_income FK_INSTRUCTION_RSJ_INCOME_INSTRUCTION_RSJ; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.instruction_rsj_income
    ADD CONSTRAINT "FK_INSTRUCTION_RSJ_INCOME_INSTRUCTION_RSJ" FOREIGN KEY ("instructionRSJId") REFERENCES public.instruction_rsj(id) ON DELETE CASCADE;


--
-- Name: instruction_rsj_mobilized_plan FK_INSTRUCTION_RSJ_MOBILIZED_PLAN_INS; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.instruction_rsj_mobilized_plan
    ADD CONSTRAINT "FK_INSTRUCTION_RSJ_MOBILIZED_PLAN_INS" FOREIGN KEY ("instructionRsjId") REFERENCES public.instruction_rsj(id) ON DELETE CASCADE;


--
-- Name: instruction_rsj_mobilized_plan FK_INSTRUCTION_RSJ_MOBILIZED_PLAN_MOB_PLA; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.instruction_rsj_mobilized_plan
    ADD CONSTRAINT "FK_INSTRUCTION_RSJ_MOBILIZED_PLAN_MOB_PLA" FOREIGN KEY ("rsjMobilizedPlanId") REFERENCES public.rsj_mobilized_plan(id) ON DELETE CASCADE;


--
-- Name: instruction_rsj_situation FK_INSTRUCTION_RSJ_SITUATION_INS; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.instruction_rsj_situation
    ADD CONSTRAINT "FK_INSTRUCTION_RSJ_SITUATION_INS" FOREIGN KEY ("instructionRsjId") REFERENCES public.instruction_rsj(id) ON DELETE CASCADE;


--
-- Name: instruction_rsj_situation FK_INSTRUCTION_RSJ_SITUATION_SIT; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.instruction_rsj_situation
    ADD CONSTRAINT "FK_INSTRUCTION_RSJ_SITUATION_SIT" FOREIGN KEY ("rsjSituationId") REFERENCES public.rsj_situation(id) ON DELETE CASCADE;


--
-- Name: instruction_rsj FK_INSTRUCTION_RSJ_STRUCTURE; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.instruction_rsj
    ADD CONSTRAINT "FK_INSTRUCTION_RSJ_STRUCTURE" FOREIGN KEY ("structureId") REFERENCES public.structure(id) ON DELETE CASCADE;


--
-- Name: instruction_rsj FK_INSTRUCTION_RSJ_USER; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.instruction_rsj
    ADD CONSTRAINT "FK_INSTRUCTION_RSJ_USER" FOREIGN KEY ("directedById") REFERENCES public."user"(id);


--
-- Name: instruction_rsj FK_INS_RSJ_ADD_DOC_1; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.instruction_rsj
    ADD CONSTRAINT "FK_INS_RSJ_ADD_DOC_1" FOREIGN KEY ("addressDocument1Id") REFERENCES public.document(id);


--
-- Name: instruction_rsj FK_INS_RSJ_ADD_DOC_2; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.instruction_rsj
    ADD CONSTRAINT "FK_INS_RSJ_ADD_DOC_2" FOREIGN KEY ("addressDocument2Id") REFERENCES public.document(id);


--
-- Name: instruction_rsj FK_INS_RSJ_CRED_DOC_1; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.instruction_rsj
    ADD CONSTRAINT "FK_INS_RSJ_CRED_DOC_1" FOREIGN KEY ("credentialDocument1Id") REFERENCES public.document(id);


--
-- Name: instruction_rsj FK_INS_RSJ_CRED_DOC_2; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.instruction_rsj
    ADD CONSTRAINT "FK_INS_RSJ_CRED_DOC_2" FOREIGN KEY ("credentialDocument2Id") REFERENCES public.document(id);


--
-- Name: instruction_rsj FK_INS_RSJ_CRED_DOC_3; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.instruction_rsj
    ADD CONSTRAINT "FK_INS_RSJ_CRED_DOC_3" FOREIGN KEY ("credentialDocument3Id") REFERENCES public.document(id);


--
-- Name: instruction_rsj FK_INS_RSJ_NON_RENEWAL; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.instruction_rsj
    ADD CONSTRAINT "FK_INS_RSJ_NON_RENEWAL" FOREIGN KEY ("nonRenewalId") REFERENCES public.instruction_rsj_non_renewal(id);


--
-- Name: instruction_rsj_other_document FK_INS_RSJ_OTHER_DOC_DOC; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.instruction_rsj_other_document
    ADD CONSTRAINT "FK_INS_RSJ_OTHER_DOC_DOC" FOREIGN KEY ("documentId") REFERENCES public.document(id) ON DELETE CASCADE;


--
-- Name: instruction_rsj_other_document FK_INS_RSJ_OTHER_DOC_INS; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.instruction_rsj_other_document
    ADD CONSTRAINT "FK_INS_RSJ_OTHER_DOC_INS" FOREIGN KEY ("instructionRsjId") REFERENCES public.instruction_rsj(id) ON DELETE CASCADE;


--
-- Name: instruction_rsj FK_INS_RSJ_POS_ADD; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.instruction_rsj
    ADD CONSTRAINT "FK_INS_RSJ_POS_ADD" FOREIGN KEY ("postalAddressId") REFERENCES public.beneficiary_address(id);


--
-- Name: instruction_rsj FK_INS_RSJ_RES_ADD; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.instruction_rsj
    ADD CONSTRAINT "FK_INS_RSJ_RES_ADD" FOREIGN KEY ("residentialAddressId") REFERENCES public.beneficiary_address(id);


--
-- Name: instruction_rsj FK_INS_RSJ_SUP_DOC_1; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.instruction_rsj
    ADD CONSTRAINT "FK_INS_RSJ_SUP_DOC_1" FOREIGN KEY ("supervisionDocument1Id") REFERENCES public.document(id);


--
-- Name: instruction_rsj FK_INS_RSJ_SUP_DOC_2; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.instruction_rsj
    ADD CONSTRAINT "FK_INS_RSJ_SUP_DOC_2" FOREIGN KEY ("supervisionDocument2Id") REFERENCES public.document(id);


--
-- Name: instruction_rsj FK_INS_RSJ_USE_TITLE; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.instruction_rsj
    ADD CONSTRAINT "FK_INS_RSJ_USE_TITLE" FOREIGN KEY ("useTitleId") REFERENCES public.instruction_rsj_use_title(id);


--
-- Name: interview FK_INTERVIEW_BENEFICIARY; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.interview
    ADD CONSTRAINT "FK_INTERVIEW_BENEFICIARY" FOREIGN KEY ("beneficiaryId") REFERENCES public.beneficiary(id) ON DELETE CASCADE;


--
-- Name: interview FK_INTERVIEW_INTERVIEW_THEME; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.interview
    ADD CONSTRAINT "FK_INTERVIEW_INTERVIEW_THEME" FOREIGN KEY ("interviewThemeId") REFERENCES public.interview_theme(id);


--
-- Name: interview FK_INTERVIEW_STRUCTURE; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.interview
    ADD CONSTRAINT "FK_INTERVIEW_STRUCTURE" FOREIGN KEY ("structureId") REFERENCES public.structure(id);


--
-- Name: interview FK_INTERVIEW_USER; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.interview
    ADD CONSTRAINT "FK_INTERVIEW_USER" FOREIGN KEY ("directedById") REFERENCES public."user"(id);


--
-- Name: interview FK_INTERVIEW_USER_ADDRESS; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.interview
    ADD CONSTRAINT "FK_INTERVIEW_USER_ADDRESS" FOREIGN KEY ("addressId") REFERENCES public.user_address(id);


--
-- Name: job FK_JOB_DOMAIN; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.job
    ADD CONSTRAINT "FK_JOB_DOMAIN" FOREIGN KEY ("domainId") REFERENCES public.domain(id);


--
-- Name: orientation_history FK_ORIENTATION_HISTORY_BENEFICIARY; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.orientation_history
    ADD CONSTRAINT "FK_ORIENTATION_HISTORY_BENEFICIARY" FOREIGN KEY ("beneficiaryId") REFERENCES public.beneficiary(id) ON DELETE CASCADE;


--
-- Name: orientation_history FK_ORIENTATION_HISTORY_STRUCTURE; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.orientation_history
    ADD CONSTRAINT "FK_ORIENTATION_HISTORY_STRUCTURE" FOREIGN KEY ("structureId") REFERENCES public.structure(id);


--
-- Name: referent_history FK_REFERENT_HISTORY_BENEFICIARY; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.referent_history
    ADD CONSTRAINT "FK_REFERENT_HISTORY_BENEFICIARY" FOREIGN KEY ("beneficiaryId") REFERENCES public.beneficiary(id) ON DELETE CASCADE;


--
-- Name: referent_history FK_REFERENT_HISTORY_STRUCTURE; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.referent_history
    ADD CONSTRAINT "FK_REFERENT_HISTORY_STRUCTURE" FOREIGN KEY ("structureId") REFERENCES public.structure(id);


--
-- Name: referent_history FK_REFERENT_HISTORY_USER; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.referent_history
    ADD CONSTRAINT "FK_REFERENT_HISTORY_USER" FOREIGN KEY ("referentId") REFERENCES public."user"(id);


--
-- Name: beneficiary_rsj_payment_data_history FK_REFERENT_RSJ_PAYMENT_DATA_HISTORY_DATA; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.beneficiary_rsj_payment_data_history
    ADD CONSTRAINT "FK_REFERENT_RSJ_PAYMENT_DATA_HISTORY_DATA" FOREIGN KEY ("rsjPaymentDataId") REFERENCES public.rsj_payment_data(id) ON DELETE CASCADE;


--
-- Name: beneficiary_rsj_payment_data_history FK_REFERENT_RSJ_PAYMENT_DATA_HISTORY_RSJ; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.beneficiary_rsj_payment_data_history
    ADD CONSTRAINT "FK_REFERENT_RSJ_PAYMENT_DATA_HISTORY_RSJ" FOREIGN KEY ("beneficiaryRsjId") REFERENCES public.beneficiary_rsj(id) ON DELETE CASCADE;


--
-- Name: beneficiary_rsj_referent_history FK_REFERENT_RSJ_REFERENT_HISTORY_REF; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.beneficiary_rsj_referent_history
    ADD CONSTRAINT "FK_REFERENT_RSJ_REFERENT_HISTORY_REF" FOREIGN KEY ("referentId") REFERENCES public.referent(id) ON DELETE CASCADE;


--
-- Name: beneficiary_rsj_referent_history FK_REFERENT_RSJ_REFERENT_HISTORY_RSJ; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.beneficiary_rsj_referent_history
    ADD CONSTRAINT "FK_REFERENT_RSJ_REFERENT_HISTORY_RSJ" FOREIGN KEY ("beneficiaryRsjId") REFERENCES public.beneficiary_rsj(id) ON DELETE CASCADE;


--
-- Name: referent FK_REFERENT_USER; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.referent
    ADD CONSTRAINT "FK_REFERENT_USER" FOREIGN KEY ("userId") REFERENCES public."user"(id);


--
-- Name: refresh_token FK_REFRESH_TOKEN_USER; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.refresh_token
    ADD CONSTRAINT "FK_REFRESH_TOKEN_USER" FOREIGN KEY ("userId") REFERENCES public."user"(id);


--
-- Name: rsj_payment FK_RSJ_PAYMENT_BENEFICIARY_RSJ; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.rsj_payment
    ADD CONSTRAINT "FK_RSJ_PAYMENT_BENEFICIARY_RSJ" FOREIGN KEY ("beneficiaryRsjId") REFERENCES public.beneficiary_rsj(id);


--
-- Name: rsj_payment_data FK_RSJ_PAYMENT_DATA_DOCUMENT; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.rsj_payment_data
    ADD CONSTRAINT "FK_RSJ_PAYMENT_DATA_DOCUMENT" FOREIGN KEY ("ribId") REFERENCES public.document(id);


--
-- Name: rsj_payment FK_RSJ_PAYMENT_INS_RSJ; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.rsj_payment
    ADD CONSTRAINT "FK_RSJ_PAYMENT_INS_RSJ" FOREIGN KEY ("instructionRsjId") REFERENCES public.instruction_rsj(id) ON DELETE CASCADE;


--
-- Name: rsj_payment FK_RSJ_PAYMENT_PAYMENT_DATA; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.rsj_payment
    ADD CONSTRAINT "FK_RSJ_PAYMENT_PAYMENT_DATA" FOREIGN KEY ("paymentDataId") REFERENCES public.rsj_payment_data(id) ON DELETE CASCADE;


--
-- Name: rsj_payment FK_RSJ_PAYMENT_STATE; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.rsj_payment
    ADD CONSTRAINT "FK_RSJ_PAYMENT_STATE" FOREIGN KEY ("stateId") REFERENCES public.rsj_payment_state(id);


--
-- Name: course FK_SESSION_COURSE; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.course
    ADD CONSTRAINT "FK_SESSION_COURSE" FOREIGN KEY ("sessionId") REFERENCES public.session(id) ON DELETE CASCADE;


--
-- Name: signature FK_SIGNATURE_CONTRACT; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.signature
    ADD CONSTRAINT "FK_SIGNATURE_CONTRACT" FOREIGN KEY ("contractId") REFERENCES public.contract(id) ON DELETE CASCADE;


--
-- Name: signature FK_SIGNATURE_CONTRACT_IER; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.signature
    ADD CONSTRAINT "FK_SIGNATURE_CONTRACT_IER" FOREIGN KEY ("contractIerId") REFERENCES public.contract_ier(id) ON DELETE CASCADE;


--
-- Name: signature FK_SIGNATURE_INS_RSJ; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.signature
    ADD CONSTRAINT "FK_SIGNATURE_INS_RSJ" FOREIGN KEY ("instructionRsjId") REFERENCES public.instruction_rsj(id) ON DELETE CASCADE;


--
-- Name: signature FK_SIGNATURE_USER; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.signature
    ADD CONSTRAINT "FK_SIGNATURE_USER" FOREIGN KEY ("userId") REFERENCES public."user"(id);


--
-- Name: stage FK_STAGE_BENEFICIARY; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.stage
    ADD CONSTRAINT "FK_STAGE_BENEFICIARY" FOREIGN KEY ("beneficiaryId") REFERENCES public.beneficiary(id) ON DELETE CASCADE;


--
-- Name: stage FK_STAGE_COMMUNITYACTION; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.stage
    ADD CONSTRAINT "FK_STAGE_COMMUNITYACTION" FOREIGN KEY ("communityActionId") REFERENCES public.community_action(id);


--
-- Name: stage FK_STAGE_ENROL; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.stage
    ADD CONSTRAINT "FK_STAGE_ENROL" FOREIGN KEY ("enrolId") REFERENCES public.enrol(id) ON DELETE SET NULL;


--
-- Name: stage FK_STAGE_NATURE_TYPE; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.stage
    ADD CONSTRAINT "FK_STAGE_NATURE_TYPE" FOREIGN KEY ("stageNatureTypeId") REFERENCES public.stage_nature_type(id);


--
-- Name: stage FK_STAGE_ORAGANIZATION_STRUTURE; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.stage
    ADD CONSTRAINT "FK_STAGE_ORAGANIZATION_STRUTURE" FOREIGN KEY ("organizationStructureId") REFERENCES public.structure(id);


--
-- Name: stage FK_STAGE_STRUCTURE; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.stage
    ADD CONSTRAINT "FK_STAGE_STRUCTURE" FOREIGN KEY ("structureId") REFERENCES public.structure(id);


--
-- Name: structure_focus_area FK_STRUCTURE_FOCUS_AREA_AREA; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.structure_focus_area
    ADD CONSTRAINT "FK_STRUCTURE_FOCUS_AREA_AREA" FOREIGN KEY ("focusAreaId") REFERENCES public.focus_area(id) ON DELETE CASCADE;


--
-- Name: structure_focus_area FK_STRUCTURE_FOCUS_AREA_STRU; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.structure_focus_area
    ADD CONSTRAINT "FK_STRUCTURE_FOCUS_AREA_STRU" FOREIGN KEY ("structureId") REFERENCES public.structure(id) ON DELETE CASCADE;


--
-- Name: structure FK_STRUCTURE_LOGO; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.structure
    ADD CONSTRAINT "FK_STRUCTURE_LOGO" FOREIGN KEY ("logoId") REFERENCES public.logo(id);


--
-- Name: structure_to_area FK_STRUCTURE_TO_AREA_STRUCTURE; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.structure_to_area
    ADD CONSTRAINT "FK_STRUCTURE_TO_AREA_STRUCTURE" FOREIGN KEY ("structureId") REFERENCES public.structure(id);


--
-- Name: structure_to_area FK_STRUCTURE_TO_AREA_SUPPORT_TYPE; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.structure_to_area
    ADD CONSTRAINT "FK_STRUCTURE_TO_AREA_SUPPORT_TYPE" FOREIGN KEY ("supportTypeId") REFERENCES public.support_type(id);


--
-- Name: structure_to_area FK_STRUTURE_TO_AREA_CLI; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.structure_to_area
    ADD CONSTRAINT "FK_STRUTURE_TO_AREA_CLI" FOREIGN KEY ("cliId") REFERENCES public.cli(id);


--
-- Name: support_history FK_SUPPORT_HISTORY_BENEFICIARY; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.support_history
    ADD CONSTRAINT "FK_SUPPORT_HISTORY_BENEFICIARY" FOREIGN KEY ("beneficiaryId") REFERENCES public.beneficiary(id) ON DELETE CASCADE;


--
-- Name: support_history FK_SUPPORT_HISTORY_SUPPORT_TYPE; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.support_history
    ADD CONSTRAINT "FK_SUPPORT_HISTORY_SUPPORT_TYPE" FOREIGN KEY ("supportTypeId") REFERENCES public.support_type(id);


--
-- Name: survey_fse FK_SURVEY_FSE_BENEFICIARY; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.survey_fse
    ADD CONSTRAINT "FK_SURVEY_FSE_BENEFICIARY" FOREIGN KEY ("beneficiaryId") REFERENCES public.beneficiary(id) ON DELETE CASCADE;


--
-- Name: survey_fse FK_SURVEY_FSE_COMMUNITY_ACTION; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.survey_fse
    ADD CONSTRAINT "FK_SURVEY_FSE_COMMUNITY_ACTION" FOREIGN KEY ("actionId") REFERENCES public.community_action(id) ON DELETE CASCADE;


--
-- Name: survey_fse FK_SURVEY_FSE_ORGANIZATION_STRUCTURE; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.survey_fse
    ADD CONSTRAINT "FK_SURVEY_FSE_ORGANIZATION_STRUCTURE" FOREIGN KEY ("structureOrganizationId") REFERENCES public.structure(id) ON DELETE CASCADE;


--
-- Name: survey_fse FK_SURVEY_FSE_USER; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.survey_fse
    ADD CONSTRAINT "FK_SURVEY_FSE_USER" FOREIGN KEY ("directedById") REFERENCES public."user"(id);


--
-- Name: traceability FK_TRACEABILITY_CONTRACT; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.traceability
    ADD CONSTRAINT "FK_TRACEABILITY_CONTRACT" FOREIGN KEY ("contractId") REFERENCES public.contract(id) ON DELETE CASCADE;


--
-- Name: traceability FK_TRACEABILITY_CONTRACT_IER; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.traceability
    ADD CONSTRAINT "FK_TRACEABILITY_CONTRACT_IER" FOREIGN KEY ("contractIerId") REFERENCES public.contract_ier(id) ON DELETE CASCADE;


--
-- Name: traceability FK_TRACEABILITY_INS_RSJ; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.traceability
    ADD CONSTRAINT "FK_TRACEABILITY_INS_RSJ" FOREIGN KEY ("instructionRsjId") REFERENCES public.instruction_rsj(id) ON DELETE CASCADE;


--
-- Name: user_address FK_USER_ADDRESS_USER; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.user_address
    ADD CONSTRAINT "FK_USER_ADDRESS_USER" FOREIGN KEY ("userId") REFERENCES public."user"(id);


--
-- Name: user FK_USER_CLI; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT "FK_USER_CLI" FOREIGN KEY ("cliId") REFERENCES public.cli(id);


--
-- Name: user_ctm FK_USER_CTM_CTMID; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.user_ctm
    ADD CONSTRAINT "FK_USER_CTM_CTMID" FOREIGN KEY ("ctmId") REFERENCES public.ctm(id) ON DELETE CASCADE;


--
-- Name: user_ctm FK_USER_CTM_USER; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.user_ctm
    ADD CONSTRAINT "FK_USER_CTM_USER" FOREIGN KEY ("userId") REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: user_group FK_USER_CTM_USER; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.user_group
    ADD CONSTRAINT "FK_USER_CTM_USER" FOREIGN KEY ("userId") REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: user_group FK_USER_GROUP_GROUPNAME; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.user_group
    ADD CONSTRAINT "FK_USER_GROUP_GROUPNAME" FOREIGN KEY ("groupName") REFERENCES public."group"(name) ON DELETE CASCADE;


--
-- Name: user_notification FK_USER_NOTIFICATION_USER; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public.user_notification
    ADD CONSTRAINT "FK_USER_NOTIFICATION_USER" FOREIGN KEY ("userId") REFERENCES public."user"(id);


--
-- Name: user FK_USER_STRUCTURE_ID; Type: FK CONSTRAINT; Schema: public; Owner: insertion
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT "FK_USER_STRUCTURE_ID" FOREIGN KEY ("structureId") REFERENCES public.structure(id);


--
-- PostgreSQL database dump complete
--

